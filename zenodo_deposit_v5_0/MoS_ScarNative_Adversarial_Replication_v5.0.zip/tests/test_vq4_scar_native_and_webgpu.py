"""Dual-Engine Verification Suite (`Native PyTorch CPU/MPS` + `Physical WebGPU WGSL 1.0`) for `VQ4-Scar`.

Enforces Ecosystem Rule #5:
  Every `VQ4-Scar` (`4D LUT256` + `d_eq` + `FWHT-64` + `2-Pass INT4-ASVD`) operator MUST run
  with verified numerical parity (`cosine > 0.999999`) across BOTH:
    1. Native Engine (`PyTorch CPU / Metal MPS / CUDA` via `VQ4ScarLinear`)
    2. Web Engine (`Physical WebGPU WGSL 1.0` via `vq4_equilibrate_fwht64` & `mos_fused_vq4_int4scar_gemv`)
  and across all 4 target languages (`PT`, `EN`, `ES`, `FR`) on strictly disjoint held-out tokens.
"""

from __future__ import annotations

import numpy as np
import pytest
import torch
import torch.nn as nn
import torch.nn.functional as F

from scar_cache.sub2bit_mos import dequantize_sub2bit_coalesced, quantize_sub2bit_block64
from scar_cache.vq4_scar_mos import (
    ScriptSubspaceGate,
    VQ4ScarLinear,
    WebGPUVQ4ScarExecutor,
    has_cjk_script,
    quantize_matrix_vq4_scar_2pass,
    quantize_protected_int4_2pass,
)


def test_vq4_scar_exact_zero_and_byte_budget() -> None:
    torch.manual_seed(42)
    lin = nn.Linear(512, 1024, bias=True)
    # Zero out the first 64-weight block of row 0 to verify exact zero preservation via LUT[0] = (0,0,0,0)
    with torch.no_grad():
        lin.weight[0, :64].zero_()

    packed = quantize_matrix_vq4_scar_2pass(lin.weight, col_rms=None, bias=lin.bias, rank=32, two_pass=True)
    assert torch.all(packed.lut256_f16[0] == 0.0), "LUT256[0] must be hard-pinned to exact (0,0,0,0)!"

    expected_bytes = (
        (1024 * 512) // 4             # VQ4 1-byte indices (2.00 bpw)
        + ((1024 * 512) // 64) * 2    # FP16 block-64 scales (0.25 bpw)
        + 256 * 4 * 2                 # 2 KB LUT256
        + 512 * 2                     # FP16 channel equilibration d_eq
        + (32 * 512) // 2             # INT4 A_scar nibbles
        + ((32 * 512) // 64) * 2      # FP16 A_scar block scales
        + (1024 * 32) // 2            # INT4 B_scar nibbles
        + 1024 * 2                    # FP16 B_scar row scales
        + 1024 * 2                    # FP16 bias
    )
    assert packed.physical_bytes == expected_bytes


def test_vq4_scar_native_cpu_and_mps_outlier_healing() -> None:
    torch.manual_seed(2026)
    in_dim, out_dim = 512, 1024
    lin = nn.Linear(in_dim, out_dim, bias=False)

    # Disjoint calibration vs held-out test activations with realistic 300x channel outliers!
    outlier_profile = torch.ones(in_dim)
    outlier_profile[7] = 280.0
    outlier_profile[131] = 420.0
    outlier_profile[389] = 190.0

    with torch.no_grad():
        # Counter-scale outlier columns in W (just like real Transformer layers!)
        lin.weight.mul_(0.04 / outlier_profile.sqrt().unsqueeze(0))
        x_calib = torch.randn(256, in_dim) * outlier_profile.unsqueeze(0)
        x_heldout = torch.randn(192, in_dim) * outlier_profile.unsqueeze(0)

        col_rms = x_calib.square().mean(dim=0).sqrt()
        y_ref = lin(x_heldout)
        ref_norm = y_ref.norm().item()

        # Legacy scalar 2-bit baseline
        p2, s2 = quantize_sub2bit_block64(lin.weight.float())
        w_s2 = dequantize_sub2bit_coalesced(p2, s2, lin.weight.shape, torch.float32)
        err_scalar2 = (x_heldout @ w_s2.T - y_ref).norm().item() / ref_norm

        # VQ4-Scar 1-Pass vs 2-Pass on Native CPU
        vq_1pass = VQ4ScarLinear.from_linear(lin, col_rms=col_rms, rank=32, two_pass=False)
        vq_2pass = VQ4ScarLinear.from_linear(lin, col_rms=col_rms, rank=32, two_pass=True)

        y_cpu_1 = vq_1pass(x_heldout)
        y_cpu_2 = vq_2pass(x_heldout)
        err_1pass = (y_cpu_1 - y_ref).norm().item() / ref_norm
        err_2pass = (y_cpu_2 - y_ref).norm().item() / ref_norm

        assert err_2pass < err_1pass, f"2-Pass ({err_2pass:.4f}) should beat 1-Pass ({err_1pass:.4f})"
        assert err_2pass < 0.35 * err_scalar2, (
            f"VQ4-Scar 2-Pass ({err_2pass:.4f}) must crush scalar 2-bit ({err_scalar2:.4f}) on outlier channels!"
        )

        # Native Metal MPS parity check (when MPS is available on Apple Silicon)
        if torch.backends.mps.is_available():
            dev_mps = torch.device("mps")
            vq_mps = vq_2pass.to(dev_mps)
            y_mps = vq_mps(x_heldout.to(dev_mps)).cpu()
            cos_cpu_mps = F.cosine_similarity(y_cpu_2.flatten(), y_mps.flatten(), dim=0).item()
            assert cos_cpu_mps > 0.999999, f"Native CPU vs MPS cosine drift: {cos_cpu_mps}"


def test_vq4_scar_physical_webgpu_wgsl_parity_with_native() -> None:
    pytest.importorskip("wgpu")
    torch.manual_seed(777)

    executor = WebGPUVQ4ScarExecutor()
    for rank, has_bias in ((0, False), (48, True)):
        lin = nn.Linear(768, 1536, bias=has_bias)
        col_rms = torch.linspace(0.5, 25.0, 768)
        col_rms[19] = 310.0

        vq_lin = VQ4ScarLinear.from_linear(lin, col_rms=col_rms, rank=rank, two_pass=True)
        x_test = torch.randn(6, 768) * col_rms.sqrt().unsqueeze(0)

        y_native = vq_lin(x_test).detach().cpu().numpy()
        y_webgpu = executor.execute_gemv(vq_lin.as_packed(), x_test.numpy())

        cos = float(
            np.dot(y_native.ravel(), y_webgpu.ravel())
            / (np.linalg.norm(y_native.ravel()) * np.linalg.norm(y_webgpu.ravel()) + 1e-12)
        )
        max_abs = float(np.max(np.abs(y_native - y_webgpu)))
        rel_l2 = float(np.linalg.norm(y_native - y_webgpu) / (np.linalg.norm(y_native) + 1e-12))

        assert cos > 0.999999, f"WebGPU WGSL vs Native PyTorch cosine={cos} (rank={rank})"
        assert rel_l2 < 1e-5, f"WebGPU WGSL vs Native PyTorch rel_l2={rel_l2} (rank={rank})"
        assert max_abs < 2e-3, f"WebGPU WGSL vs Native PyTorch max_abs={max_abs} (rank={rank})"


def test_vq4_scar_real_qwen_polyglot_native_and_webgpu() -> None:
    """End-to-end polyglot (`PT / EN / ES / FR`) test on real Qwen2.5 weights across BOTH Native & WebGPU!"""
    pytest.importorskip("wgpu")
    from transformers import AutoModelForCausalLM, AutoTokenizer

    model_id = "Qwen/Qwen2.5-0.5B-Instruct"
    try:
        tok = AutoTokenizer.from_pretrained(model_id, local_files_only=True)
        model = AutoModelForCausalLM.from_pretrained(model_id, dtype=torch.float32, local_files_only=True)
    except Exception:
        pytest.skip(f"{model_id} not cached locally")

    model.eval()
    dev = torch.device("mps" if torch.backends.mps.is_available() else "cpu")
    model.to(dev)

    # Strictly disjoint 4-language calibration texts vs 4-language held-out test texts
    calib_texts = [
        "A fotossíntese converte luz solar em energia química dentro dos cloroplastos das plantas.",
        "Binary search halves a sorted array at each step to achieve logarithmic lookup complexity.",
        "Las estrellas fusionan hidrógeno en helio manteniendo el equilibrio frente a la gravedad.",
        "Les récifs coralliens abritent une biodiversité marine exceptionnelle dans les océans.",
    ]
    heldout_by_lang = {
        "PT": "Explique a mecânica quântica e o limite termodinâmico de Landauer com a constante de Boltzmann.",
        "EN": "Explain quantum mechanics and Landauer's thermodynamic limit via Boltzmann's constant.",
        "ES": "Explica la mecánica cuántica y el límite termodinámico de Landauer con la constante de Boltzmann.",
        "FR": "Expliquez la mécanique quantique et la limite thermodynamique de Landauer via la constante de Boltzmann.",
    }

    target_mlp = model.model.layers[12].mlp
    gate_sq = torch.zeros(target_mlp.gate_proj.in_features, device=dev)
    down_sq = torch.zeros(target_mlp.down_proj.in_features, device=dev)
    n_cal = 0

    def _h_gate(_m, inp, _o):
        nonlocal gate_sq, n_cal
        x = inp[0].detach().float().reshape(-1, inp[0].shape[-1])
        gate_sq += x.square().sum(dim=0)
        n_cal += x.shape[0]

    def _h_down(_m, inp, _o):
        nonlocal down_sq
        x = inp[0].detach().float().reshape(-1, inp[0].shape[-1])
        down_sq += x.square().sum(dim=0)

    hg = target_mlp.gate_proj.register_forward_hook(_h_gate)
    hd = target_mlp.down_proj.register_forward_hook(_h_down)
    with torch.no_grad():
        for txt in calib_texts:
            model(tok(txt, return_tensors="pt")["input_ids"].to(dev), use_cache=False)
    hg.remove()
    hd.remove()

    gate_rms = (gate_sq / n_cal).sqrt().clamp(min=1e-6)
    down_rms = (down_sq / n_cal).sqrt().clamp(min=1e-6)

    # Quantize real Qwen `gate_proj` & `down_proj` into unified `VQ4ScarLinear` (`rank=48`, 2-Pass)
    vq_gate = VQ4ScarLinear.from_linear(target_mlp.gate_proj, col_rms=gate_rms, rank=48, two_pass=True).to(dev)
    vq_down = VQ4ScarLinear.from_linear(target_mlp.down_proj, col_rms=down_rms, rank=48, two_pass=True).to(dev)

    # Legacy scalar 2-bit reference for comparison
    pg, sg = quantize_sub2bit_block64(target_mlp.gate_proj.weight.detach().float())
    wg_s2 = dequantize_sub2bit_coalesced(pg, sg, target_mlp.gate_proj.weight.shape, torch.float32).to(dev)
    pd, sd = quantize_sub2bit_block64(target_mlp.down_proj.weight.detach().float())
    wd_s2 = dequantize_sub2bit_coalesced(pd, sd, target_mlp.down_proj.weight.shape, torch.float32).to(dev)

    executor = WebGPUVQ4ScarExecutor()

    for lang, prompt in heldout_by_lang.items():
        cap: dict[str, torch.Tensor] = {}

        def _cap_g(_m, inp, _o):
            cap["xg"] = inp[0].detach().float().reshape(-1, inp[0].shape[-1])

        def _cap_d(_m, inp, _o):
            cap["xd"] = inp[0].detach().float().reshape(-1, inp[0].shape[-1])

        h1 = target_mlp.gate_proj.register_forward_hook(_cap_g)
        h2 = target_mlp.down_proj.register_forward_hook(_cap_d)
        with torch.no_grad():
            model(tok(prompt, return_tensors="pt")["input_ids"].to(dev), use_cache=False)
        h1.remove()
        h2.remove()

        xg, xd = cap["xg"], cap["xd"]
        yg_ref = target_mlp.gate_proj(xg)
        yd_ref = target_mlp.down_proj(xd)

        # 1. Native PyTorch (`MPS/CPU`) accuracy across all 4 languages
        yg_nat = vq_gate(xg)
        yd_nat = vq_down(xd)

        err_gate_vq4 = (yg_nat - yg_ref).norm().item() / yg_ref.norm().item()
        err_gate_s2 = (xg @ wg_s2.T - yg_ref).norm().item() / yg_ref.norm().item()
        err_down_vq4 = (yd_nat - yd_ref).norm().item() / yd_ref.norm().item()
        err_down_s2 = (xd @ wd_s2.T - yd_ref).norm().item() / yd_ref.norm().item()

        assert err_gate_vq4 < err_gate_s2, f"[{lang}] VQ4-Scar gate ({err_gate_vq4:.3f}) must beat scalar 2-bit ({err_gate_s2:.3f})"
        assert err_down_vq4 < err_down_s2, f"[{lang}] VQ4-Scar down ({err_down_vq4:.3f}) must beat scalar 2-bit ({err_down_s2:.3f})"

        # 2. Physical WebGPU WGSL 1.0 parity against Native PyTorch on the exact language tokens!
        yg_wgpu = executor.execute_gemv(vq_gate.as_packed(), xg.cpu().numpy())
        yd_wgpu = executor.execute_gemv(vq_down.as_packed(), xd.cpu().numpy())

        yg_nat_np = yg_nat.cpu().numpy()
        yd_nat_np = yd_nat.cpu().numpy()

        cos_g = float(
            np.dot(yg_nat_np.ravel(), yg_wgpu.ravel())
            / (np.linalg.norm(yg_nat_np.ravel()) * np.linalg.norm(yg_wgpu.ravel()) + 1e-12)
        )
        cos_d = float(
            np.dot(yd_nat_np.ravel(), yd_wgpu.ravel())
            / (np.linalg.norm(yd_nat_np.ravel()) * np.linalg.norm(yd_wgpu.ravel()) + 1e-12)
        )
        assert cos_g > 0.999999, f"[{lang}] Native vs WebGPU gate cosine={cos_g}"
        assert cos_d > 0.999999, f"[{lang}] Native vs WebGPU down cosine={cos_d}"


def test_script_subspace_gate_polyglot_native_and_webgpu_parity() -> None:
    """Verifies Shader #18 `apply_script_subspace_gate` <-> Native `ScriptSubspaceGate` parity across PT/EN/ES/FR & ZH."""
    pytest.importorskip("wgpu")
    from transformers import AutoTokenizer

    model_id = "Qwen/Qwen2.5-0.5B-Instruct"
    try:
        tok = AutoTokenizer.from_pretrained(model_id, local_files_only=True)
    except Exception:
        pytest.skip(f"{model_id} not cached locally")

    vocab_size = 151936
    gate = ScriptSubspaceGate(tok, vocab_size=vocab_size, penalty=64.0)
    executor = WebGPUVQ4ScarExecutor()

    torch.manual_seed(202611)
    raw_logits = torch.randn(vocab_size, dtype=torch.float32)

    # Plant an artificial CJK logit collision (`量子` slightly above `quântica` / `quantum` / `cuántica` / `quantique`)
    cjk_tid = tok.encode("量子", add_special_tokens=False)[0]
    pt_tid = tok.encode(" quântica", add_special_tokens=False)[0]
    es_tid = tok.encode(" cuántica", add_special_tokens=False)[0]
    fr_tid = tok.encode(" quantique", add_special_tokens=False)[0]
    raw_logits[pt_tid] = 18.20
    raw_logits[es_tid] = 18.15
    raw_logits[fr_tid] = 18.10
    raw_logits[cjk_tid] = 18.35  # Would win greedy argmax without ScriptSubspaceGate!

    western_queries = {
        "PT": "Explique a física quântica e a constante de Boltzmann.",
        "EN": "Explain quantum physics and Boltzmann's constant.",
        "ES": "Explica la física cuántica y la constante de Boltzmann.",
        "FR": "Expliquez la physique quantique et la constante de Boltzmann.",
    }
    for lang, q in western_queries.items():
        assert not has_cjk_script(q)
        lg_nat = gate.apply_native(raw_logits, q).numpy()
        lg_web = executor.execute_script_gate(
            raw_logits.numpy(), gate.bitmask_u32, suppress_cjk=True, penalty=64.0
        )
        max_diff = float(np.max(np.abs(lg_nat - lg_web)))
        assert max_diff == 0.0, f"[{lang}] Exact bit parity required on Shader #18, got max_diff={max_diff}"
        winner_tid = int(np.argmax(lg_web))
        assert winner_tid == pt_tid, f"[{lang}] Expected accented Western token {pt_tid} to win over CJK collision!"
        assert not has_cjk_script(tok.decode([winner_tid]))

    # CJK prompt must leave CJK logits 100% untouched (`0.00000000` invariance)
    zh_q = "请解释量子力学和玻尔兹曼常数。"
    assert has_cjk_script(zh_q)
    lg_zh_nat = gate.apply_native(raw_logits, zh_q).numpy()
    lg_zh_web = executor.execute_script_gate(
        raw_logits.numpy(), gate.bitmask_u32, suppress_cjk=False, penalty=64.0
    )
    assert float(np.max(np.abs(lg_zh_nat - raw_logits.numpy()))) == 0.0
    assert float(np.max(np.abs(lg_zh_web - raw_logits.numpy()))) == 0.0
    assert int(np.argmax(lg_zh_web)) == cjk_tid


def test_protected_int4_scar_physical_webgpu_wgsl_parity() -> None:
    """Verifies Shaders #19 `vec_equilibrate_f16` & #20 `mos_fused_prot_int4_int4scar_gemv` (`r=0` and `r=24`)."""
    pytest.importorskip("wgpu")
    torch.manual_seed(20261114)

    executor = WebGPUVQ4ScarExecutor()
    for rank, has_bias, use_eq in ((0, True, True), (24, False, True), (24, True, False)):
        lin = nn.Linear(2048, 1024, bias=has_bias)
        col_rms = torch.linspace(0.4, 18.0, 2048)
        col_rms[11] = 260.0
        col_rms[1027] = 390.0

        prot_mat = quantize_protected_int4_2pass(
            lin.weight,
            col_rms=col_rms,
            bias=lin.bias,
            rank=rank,
            use_eq=use_eq,
        )
        x_test = torch.randn(5, 2048) * col_rms.sqrt().unsqueeze(0)

        y_native = prot_mat.forward_native(x_test).detach().cpu().numpy()
        y_webgpu = executor.execute_prot_int4_gemv(prot_mat, x_test.numpy())

        cos = float(
            np.dot(y_native.ravel(), y_webgpu.ravel())
            / (np.linalg.norm(y_native.ravel()) * np.linalg.norm(y_webgpu.ravel()) + 1e-12)
        )
        rel_l2 = float(np.linalg.norm(y_native - y_webgpu) / (np.linalg.norm(y_native) + 1e-12))
        assert cos > 0.999999, f"ProtectedInt4Scar WGSL vs Native cosine={cos} (r={rank}, eq={use_eq})"
        assert rel_l2 < 1e-5, f"ProtectedInt4Scar WGSL vs Native rel_l2={rel_l2} (r={rank}, eq={use_eq})"


def test_full_webgpu_mos_engine_20_shaders_polyglot() -> None:
    """Verifies `NativeWebGPUMoSEngine` compiles all 20 WGSL 1.0 shaders and runs PT/EN/ES/FR with 0% CJK leak & Δ +0 B."""
    pytest.importorskip("wgpu")
    from pathlib import Path

    from scar_cache.webgpu_engine import NativeWebGPUMoSEngine

    bundle_dir = Path("/Users/juliocesarreisfilho/Projects/portfolio/public/webgpu/qwen0p5b")
    if not (bundle_dir / "webgpu_manifest.json").exists():
        pytest.skip("qwen0p5b WebGPU bundle not present")

    eng = NativeWebGPUMoSEngine(bundle_dir)
    assert len(eng.pipelines) == 20, f"Expected all 20 WGSL 1.0 pipelines compiled, got {len(eng.pipelines)}"
    b0 = eng.scache_gpu_bytes

    for lang, q in (
        ("PT", "Quem criou o Mixture of Scars?"),
        ("EN", "What is SCache O(1)?"),
        ("ES", "¿Qué es Mixture of Scars?"),
        ("FR", "Qu'est-ce que SCache O(1) ?"),
    ):
        res = eng.generate(q, max_new_tokens=28, reset_cache=False)
        assert res.scache_delta_bytes == 0, f"[{lang}] SCache O(1) drifted by {res.scache_delta_bytes} B!"
        assert eng.scache_gpu_bytes == b0
        assert not has_cjk_script(res.answer), f"[{lang}] CJK leak detected: {res.answer}"
        assert len(res.answer.strip()) > 10


def test_out_of_cone_epistemic_guard_polyglot_qwen3b_webgpu() -> None:
    """Verifies Qwen2.5-3B `enable_epistemic_guard=True` abstains on out-of-cone traps across PT/EN/ES/FR while preserving STEM & In-Cone cartridges (`Δ +0 B`)."""
    pytest.importorskip("wgpu")
    import re
    from pathlib import Path

    from scar_cache.webgpu_engine import (
        OUT_OF_CONE_EPISTEMIC_GATES,
        NativeWebGPUMoSEngine,
        select_out_of_cone_epistemic_gate,
    )

    cheat_re = re.compile(r"\b(?:cabelo|progressiva|descolorid|bleach|keratin|alisament|shampoo)\b", re.IGNORECASE)
    for lg, gate_txt in OUT_OF_CONE_EPISTEMIC_GATES.items():
        assert not cheat_re.search(gate_txt), f"Forbidden domain cheat word in {lg} epistemic gate!"

    assert (
        select_out_of_cone_epistemic_gate(
            "Para um cabelo já liso e descolorido, qual progressiva química você recomenda?"
        )
        == OUT_OF_CONE_EPISTEMIC_GATES["pt"]
    )
    assert (
        select_out_of_cone_epistemic_gate("What chemical straightening is best for bleached straight hair?")
        == OUT_OF_CONE_EPISTEMIC_GATES["en"]
    )
    assert (
        select_out_of_cone_epistemic_gate("¿Qué antibiótico debo tomar para el dolor de garganta?")
        == OUT_OF_CONE_EPISTEMIC_GATES["es"]
    )
    assert (
        select_out_of_cone_epistemic_gate("Quel soin cosmétique recommandez-vous pour des cheveux décolorés ?")
        == OUT_OF_CONE_EPISTEMIC_GATES["fr"]
    )

    bundle_3b = Path("/Users/juliocesarreisfilho/Projects/portfolio/public/webgpu/qwen3b")
    if not (bundle_3b / "webgpu_manifest.json").exists():
        pytest.skip("qwen3b WebGPU bundle not present")

    eng = NativeWebGPUMoSEngine(bundle_3b)
    b0 = eng.scache_gpu_bytes

    # Multi-turn O(1) continuity: Turn 1 In-Cone -> Turn 2 Out-of-Cone Hair Trap -> Turn 3 Out-of-Cone STEM
    r_in = eng.generate(
        "O que é o Mixture of Scars e o SCache O(1)?",
        max_new_tokens=48,
        reset_cache=True,
        enable_epistemic_guard=True,
    )
    assert r_in.epistemic_mode == "scar_grounded"
    assert "portfolio_mos_scache_72b" in r_in.active_capsules
    assert r_in.scache_delta_bytes == 0

    r_hair_pt = eng.generate(
        "Para um cabelo já liso e descolorido, as progressivas químicas são mais indicadas?",
        max_new_tokens=64,
        reset_cache=False,
        enable_epistemic_guard=True,
    )
    assert r_hair_pt.epistemic_mode == "out_of_cone_guarded"
    assert r_hair_pt.active_capsules == []
    assert r_hair_pt.scache_delta_bytes == 0 and eng.scache_gpu_bytes == b0
    ans_pt_low = r_hair_pt.answer.lower()
    assert not ("são geralmente mais indicadas" in ans_pt_low or "ajudar a restaurar" in ans_pt_low)
    assert any(
        k in ans_pt_low
        for k in ("não", "escopo", "cartucho", "scarstore", "domínio", "engenharia", "ia")
    ), f"Expected honest abstention in PT, got: {r_hair_pt.answer}"

    r_math = eng.generate(
        "Quanto é 14 vezes 7?",
        max_new_tokens=36,
        reset_cache=False,
        enable_epistemic_guard=True,
    )
    assert r_math.epistemic_mode == "out_of_cone_guarded"
    assert r_math.scache_delta_bytes == 0 and eng.scache_gpu_bytes == b0
    assert "98" in r_math.answer, f"Expected accurate STEM answer '98', got: {r_math.answer}"

    # Polyglot PT / EN / ES / FR out-of-cone abstentions on physical GPU (Turn 1 fresh SCache)
    for lang, trap_q, abstain_markers in (
        (
            "PT",
            "Para um cabelo já liso e descolorido, qual progressiva química é mais indicada?",
            ("escopo", "cartucho", "scarstore", "domínio", "engenharia", "não recomendo", "não posso", "não possuo", "não tenho"),
        ),
        (
            "EN",
            "What chemical hair straightening treatment is best for bleached straight hair?",
            ("outside", "scope", "cannot", "can't", "do not", "don't", "no verified", "cartridge", "engineering"),
        ),
        (
            "ES",
            "¿Qué tratamiento de alisado químico recomiendas para cabello decolorado?",
            ("fuera", "alcance", "cartucho", "scarstore", "dominio", "ingeniería", "no puedo", "no tengo", "asistente"),
        ),
        (
            "FR",
            "Quel lissage chimique recommandez-vous pour des cheveux déjà lisses et décolorés ?",
            ("hors", "périmètre", "aucun", "cartouche", "ingénierie", "ne peux", "ne suis pas", "pas formé"),
        ),
    ):
        r_trap = eng.generate(trap_q, max_new_tokens=72, reset_cache=True, enable_epistemic_guard=True)
        print(f"[{lang}_TRAP] -> {r_trap.answer}")
        assert r_trap.epistemic_mode == "out_of_cone_guarded"
        assert r_trap.active_capsules == []
        assert r_trap.scache_delta_bytes == 0
        assert not has_cjk_script(r_trap.answer)
        low = r_trap.answer.lower()
        assert any(m in low for m in abstain_markers), f"[{lang}] Expected abstention, got: {r_trap.answer}"


