"""Módulo de Expansão de Profundidade via Base Compartilhada e Mixture of Scars (MoS).

Permite instanciar topologias profundas (72 a 80 camadas) sobre modelos compactos (ex: Qwen2.5-3B)
em ambientes com hardware limitado (16GB GPU / Mac M2) via compartilhamento de pesos e micro-especialistas:
  1. Base Universal Compartilhada (W_base): As camadas base são reutilizadas ciclicamente em profundidade.
  2. Scar Experts de Baixo Rank (A @ B): Micro-especialistas de cicatriz por camada para especialização vertical.
  3. SCache O(1): Cache de contexto com consumo fixo via Delta Rule de Widrow-Hoff.

NOTA DE RIGOR CIENTÍFICO:
  Na inicialização zero-shot (`expert.A.zero_()`), a topologia atua como uma passagem recorrente
  sobre as camadas base (equivalente ao regime Universal Transformer / ALBERT). A divergência funcional
  entre camadas profundas requer calibração ou fine-tuning dos micro-especialistas de cicatriz.
"""

from __future__ import annotations

import time
import os
import copy
from typing import Any, Dict, Optional, Tuple, Union
import torch
import torch.nn as nn
from transformers import AutoModelForCausalLM, AutoTokenizer

from scar_cache.mos import MixtureOfScarsLinear
from scar_cache.hf_cache import SCacheDynamicCache
from scar_cache.speculative_ghost_jump import recursive_scache_storage_bytes


class NativeMoS70B:
    """Topologia Recorrente Profunda (72–80 camadas) via Base Compartilhada + MoS + SCache O(1).

    Expande ciclicamente camadas pré-treinadas compactas (regime Universal Transformer) com
    micro-especialistas `MixtureOfScarsLinear`. Para inferência nos pesos pré-treinados reais
    do `Qwen2.5-72B-Instruct` (`72.71B`, `80` camadas distintas), utilize `CanonicalMoSEngine`
    em `scar_cache.cli_72b`.
    """

    def __init__(
        self,
        model: nn.Module,
        tokenizer: Any,
        num_layers: int,
        base_layers: int,
        rank: int,
        device: torch.device,
    ) -> None:
        self.model = model
        self.tokenizer = tokenizer
        self.num_layers = num_layers
        self.base_layers = base_layers
        self.rank = rank
        self.device = device

    @classmethod
    def from_pretrained(
        cls,
        model_id: str = "Qwen/Qwen2.5-3B-Instruct",
        target_layers: int = 72,
        rank: int = 32,
        num_experts: int = 2,
        top_k: int = 1,
        torch_dtype: torch.dtype = torch.bfloat16,
        device_map: str = "auto",
    ) -> "NativeMoS70B":
        """Carrega e converte o modelo para a topologia profunda de 70B/72B via MoS em segundos."""
        t0 = time.time()
        print(f"📦 [MoS Loader] Carregando pesos pré-treinados de {model_id}...")
        tokenizer = AutoTokenizer.from_pretrained(model_id)

        # Determina dispositivo
        if device_map == "auto":
            if torch.cuda.is_available():
                device = torch.device("cuda")
            elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
                device = torch.device("mps")
            else:
                device = torch.device("cpu")
        else:
            device = torch.device(device_map)

        base_model = AutoModelForCausalLM.from_pretrained(
            model_id,
            torch_dtype=torch_dtype,
        ).to(device)
        base_model.eval()

        orig_layers = list(base_model.model.layers)
        base_count = len(orig_layers)
        print(f"  ✓ Pesos base carregados ({base_count} camadas) em {time.time() - t0:.2f}s.")

        # Expansão para topologia profunda de 70B (72 ou 80 camadas)
        print(f"🧬 [MoS Loader] Expandindo arquitetura para {target_layers} camadas com Base Compartilhada...")
        expanded = []
        for i in range(target_layers):
            expanded.append(orig_layers[i % base_count])
        base_model.model.layers = nn.ModuleList(expanded)

        # Transplante Mixture of Scars (MoS) nas MLPs
        mos_count = 0
        for i, layer in enumerate(base_model.model.layers):
            old_down = layer.mlp.down_proj
            if not isinstance(old_down, MixtureOfScarsLinear):
                mos = MixtureOfScarsLinear(
                    in_features=old_down.in_features,
                    out_features=old_down.out_features,
                    num_experts=num_experts,
                    top_k=top_k,
                    rank=rank,
                    shared_base=old_down,
                    device=device,
                    dtype=torch_dtype,
                )
                with torch.no_grad():
                    for expert in mos.experts:
                        expert.A.zero_()
                        expert.B.zero_()
                    mos.router.weight.fill_(1.0)
                layer.mlp.down_proj = mos
                mos_count += 1

        print(f"  ✓ {mos_count} camadas base equipadas com adaptadores Mixture of Scars (MoS)!")
        print(f"  ✓ Topologia expandida para {target_layers} camadas em profundidade recorrente ({base_count} camadas base compartilhadas).\n")

        return cls(
            model=base_model,
            tokenizer=tokenizer,
            num_layers=target_layers,
            base_layers=base_count,
            rank=rank,
            device=device,
        )

    def generate(
        self,
        prompt: str,
        max_new_tokens: int = 60,
        window_size: int = 128,
        num_sink_tokens: int = 4,
        do_sample: bool = False,
    ) -> Tuple[str, Dict[str, Any]]:
        """Gera texto usando SCache O(1) através de todas as camadas profundas."""
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.device)
        input_len = inputs.input_ids.shape[1]

        cache = SCacheDynamicCache(window_size=window_size, num_sink_tokens=num_sink_tokens)

        t0 = time.time()
        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                past_key_values=cache,
                max_new_tokens=max_new_tokens,
                do_sample=do_sample,
            )
        elapsed = time.time() - t0

        generated_tokens = outputs.shape[1] - input_len
        output_text = self.tokenizer.decode(outputs[0][input_len:], skip_special_tokens=True)

        phys_bytes = cache.total_physical_bytes
        rec_bytes = recursive_scache_storage_bytes(cache)
        cache_mb = phys_bytes / (1024 * 1024)

        evicted = max(0, outputs.shape[1] - window_size)
        metrics = {
            "num_layers": self.num_layers,
            "base_layers": self.base_layers,
            "input_tokens": input_len,
            "generated_tokens": generated_tokens,
            "total_tokens": outputs.shape[1],
            "elapsed_sec": elapsed,
            "tokens_per_sec": generated_tokens / max(0.001, elapsed),
            "kv_cache_mb": cache_mb,
            "kv_cache_reported_bytes": cache.total_memory_bytes,
            "kv_cache_recursive_bytes": rec_bytes,
            "kv_storage_discrepancy_bytes": abs(rec_bytes - cache.total_memory_bytes),
            "tokens_evicted": evicted,
        }

        return output_text, metrics
