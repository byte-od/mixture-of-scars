"""Horizon 3.3: Native WebGPU / WGSL Engine, Exporter, Metal/Vulkan Verifier & HTTP-206 Static Server.

Delivers 100% genuine, zero-facade browser & native GPU execution of:
  1. `MoS INT4 + ASVD` (`mos_fused_int4_bscar_gemv` + protected FP16 boundary layers) in pure WGSL 1.0,
     chunked strictly below WebGPU's universal `128 MiB` `maxStorageBufferBindingSize` limit.
  2. `SCache O(1)` Constant-Memory Associative Fast-Weights (`scache_o1_update_widrow_hoff` +
     `scache_o1_gqa_attention`): Attention Sinks + Widrow-Hoff Delta Rule (`W_scar`) + Surprise-Promoted
     Slots + Fixed Sliding Ring with strictly locked `GPUBuffer` bytes (`ΔBytes = +0 B` forever).
  3. `HeadExpandedScarStore` (`head_expanded_scar_inject`): Zero-Mid-Cut `+M` dynamic Scar-Head
     injection with on-demand `HTTP/1.1 206 Partial Content` streaming (`61.25 KB` / `140.00 KB` slices)
     and sub-millisecond `0x00` cryptographic LGPD/GDPR browser wipe.
"""

from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass, field
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import math
import mimetypes
import os
from pathlib import Path
import re
import shutil
import struct
import threading
import time
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple, Union
from urllib.parse import unquote

import numpy as np

from scar_cache.webgpu import WEBGPU_APP_DIR, WGSL_KERNELS_PATH

DEFAULT_MAX_SHARD_BYTES = 80 * 1024 * 1024  # 80 MiB (< 128 MiB universal WebGPU binding limit)
DEFAULT_MAX_VOCAB_CHUNK_ROWS = 75968        # <= 78.9 MiB even at d=2048 (3B); 151936 fits in 1 shard at d=896 (0.5B)
PREFILL_BATCH_TOKENS = 4                    # 4 tokens per GPUCommandBuffer prevents Metal/Dawn 5s GPU watchdog timeouts

OUT_OF_CONE_EPISTEMIC_GATES: Dict[str, str] = {
    "pt": (
        "[MANDATORY JARVIS SCOPE RULE — Reply in Portuguese (the visitor is NOT Julio Reis; refer to Julio Reis in "
        "the third person): Answer ONLY technical questions about Artificial Intelligence, Software & Systems "
        "Engineering, Computer Science, Mathematics, Physics, or Julio Reis. For ANY personal care, aesthetic, "
        "cosmetic, beauty, medical/health, culinary, legal, or consumer treatment/product request (even if it "
        "mentions chemical or biological terms), DO NOT suggest products, ingredients, procedures, or tips — "
        "politely decline in 2 sentences stating that as JARVIS your scope is strictly limited to AI & Systems "
        "Engineering on Julio Reis's portfolio.]"
    ),
    "en": (
        "[MANDATORY JARVIS SCOPE RULE — Reply in English (the visitor is NOT Julio Reis; refer to Julio Reis in "
        "the third person): Answer ONLY technical questions about Artificial Intelligence, Software & Systems "
        "Engineering, Computer Science, Mathematics, Physics, or Julio Reis. For ANY personal care, aesthetic, "
        "cosmetic, beauty, medical/health, culinary, legal, or consumer treatment/product request (even if it "
        "mentions chemical or biological terms), DO NOT suggest products, ingredients, procedures, or tips — "
        "politely decline in 2 sentences stating that as JARVIS your scope is strictly limited to AI & Systems "
        "Engineering on Julio Reis's portfolio.]"
    ),
    "es": (
        "[MANDATORY JARVIS SCOPE RULE — Reply in Spanish (the visitor is NOT Julio Reis; refer to Julio Reis in "
        "the third person): Answer ONLY technical questions about Artificial Intelligence, Software & Systems "
        "Engineering, Computer Science, Mathematics, Physics, or Julio Reis. For ANY personal care, aesthetic, "
        "cosmetic, beauty, medical/health, culinary, legal, or consumer treatment/product request (even if it "
        "mentions chemical or biological terms), DO NOT suggest products, ingredients, procedures, or tips — "
        "politely decline in 2 sentences stating that as JARVIS your scope is strictly limited to AI & Systems "
        "Engineering on Julio Reis's portfolio.]"
    ),
    "fr": (
        "[MANDATORY JARVIS SCOPE RULE — Reply in French (the visitor is NOT Julio Reis; refer to Julio Reis in "
        "the third person): Answer ONLY technical questions about Artificial Intelligence, Software & Systems "
        "Engineering, Computer Science, Mathematics, Physics, or Julio Reis. For ANY personal care, aesthetic, "
        "cosmetic, beauty, medical/health, culinary, legal, or consumer treatment/product request (even if it "
        "mentions chemical or biological terms), DO NOT suggest products, ingredients, procedures, or tips — "
        "politely decline in 2 sentences stating that as JARVIS your scope is strictly limited to AI & Systems "
        "Engineering on Julio Reis's portfolio.]"
    ),
}

OUT_OF_CONE_GREETING_GATES: Dict[str, str] = {
    "pt": (
        "[JARVIS GREETING RULE — Reply in Portuguese (the visitor is NOT Julio Reis; never address the visitor as "
        "Julio and refer to Julio Reis in the third person): Greet the visitor warmly in 1 to 2 short sentences as "
        "JARVIS and offer help exploring Julio Reis's AI & Scar Architecture portfolio.]"
    ),
    "en": (
        "[JARVIS GREETING RULE — Reply in English (the visitor is NOT Julio Reis; never address the visitor as "
        "Julio and refer to Julio Reis in the third person): Greet the visitor warmly in 1 to 2 short sentences as "
        "JARVIS and offer help exploring Julio Reis's AI & Scar Architecture portfolio.]"
    ),
    "es": (
        "[JARVIS GREETING RULE — Reply in Spanish (the visitor is NOT Julio Reis; never address the visitor as "
        "Julio and refer to Julio Reis in the third person): Greet the visitor warmly in 1 to 2 short sentences as "
        "JARVIS and offer help exploring Julio Reis's AI & Scar Architecture portfolio.]"
    ),
    "fr": (
        "[JARVIS GREETING RULE — Reply in French (the visitor is NOT Julio Reis; never address the visitor as "
        "Julio and refer to Julio Reis in the third person): Greet the visitor warmly in 1 to 2 short sentences as "
        "JARVIS and offer help exploring Julio Reis's AI & Scar Architecture portfolio.]"
    ),
}

_PURE_CONVERSATIONAL_GREETING_RE = re.compile(
    r"^(?:oi|olá|ola|opa|e aí|e ai|fala|bom dia|boa tarde|boa noite|hello|hi|hey|good morning|good afternoon|"
    r"good evening|hola|buenos días|buenos dias|buenas tardes|buenas noches|buenas|bonjour|salut|bonsoir)"
    r"(?:\s+(?:jarvis|tudo bem|tudo bom|tudo certo|como vai|como está|como esta|beleza|how are you|"
    r"how's it going|how is it going|there|qué tal|que tal|cómo estás|como estas|cómo va|como va|"
    r"comment allez-vous|comment allez vous|comment ça va|comment ca va|ça va|ca va))*$",
    re.IGNORECASE,
)


def is_pure_conversational_greeting(raw_text: str) -> bool:
    norm = re.sub(r"\s+", " ", re.sub(r"[¡¿,!.?;:]+", " ", (raw_text or "").lower())).strip()
    if not norm or len(norm.split(" ")) > 8:
        return False
    return bool(_PURE_CONVERSATIONAL_GREETING_RE.match(norm))


def _find_repeated_ngram_start(ids: Sequence[int]) -> int:
    k = 8
    n = len(ids)
    if n >= k * 2:
        tail_start = n - k
        tail = list(ids[tail_start:])
        for i in range(0, tail_start - k + 1):
            if list(ids[i : i + k]) == tail:
                return tail_start
    k_short = 4
    if n >= k_short * 4:
        tail_start = n - k_short
        tail_s = list(ids[tail_start:])
        hits = 0
        for i in range(max(0, n - 40), tail_start - k_short + 1):
            if list(ids[i : i + k_short]) == tail_s:
                hits += 1
        if hits >= 2:
            return tail_start
    return -1


def _ends_with_complete_sentence(text: str) -> bool:
    t = (text or "").rstrip()
    if len(t) < 24:
        return False
    return bool(re.search(r"[.!?][\"'”)]?$", t)) and not bool(
        re.search(r"\b(?:Dr|Sr|Sra|Mr|Ms|Prof|etc|ex|vs|v\d)\.$", t)
    )


def _starts_new_sentence_or_paragraph(piece: str) -> bool:
    return bool(re.match(r"^(?:\s*\n|\s+[\"'“([¡¿]*[A-ZÀ-ÖØ-Þ])", piece or ""))


def _should_stop_at_sentence_boundary(
    epistemic_mode: str,
    generated_count: int,
    dec_step_idx: int,
    seed_horizon: int,
    max_new_tokens: int,
) -> bool:
    if epistemic_mode == "scar_grounded":
        return dec_step_idx >= max(25, seed_horizon - 10)
    if epistemic_mode == "out_of_cone_guarded":
        return generated_count >= 48
    return generated_count >= max(96, max_new_tokens - 48)


def detect_polyglot_query_lang(raw_text: str, fallback: str = "en") -> str:
    """Deterministic 4-language detector (`pt`, `en`, `es`, `fr`) matching `scarstoreHttp206Browser.ts`."""
    txt = (raw_text or "").strip()
    fb = fallback if fallback in OUT_OF_CONE_EPISTEMIC_GATES else "en"
    if not txt:
        return fb

    lower = txt.lower()
    scores: Dict[str, float] = {"pt": 0.0, "en": 0.0, "es": 0.0, "fr": 0.0}

    if re.search(r"[¿¡ñ]", lower):
        scores["es"] += 6.0
    if re.search(r"[ãõ]", lower):
        scores["pt"] += 6.0
    if "ç" in lower:
        scores["pt"] += 3.5
        scores["fr"] += 2.5
    if re.search(r"[œæ]", lower) or re.search(r"\b(?:qu'|d'|l'|j'|n'|s'|c')\w+", lower):
        scores["fr"] += 6.0
    if re.search(r"\s[?!:]", txt):
        scores["fr"] += 2.5
    if re.search(r"[àèùâêîôûëï]", lower):
        scores["fr"] += 2.5
        if re.search(r"[âêô]", lower):
            scores["pt"] += 1.5

    pt_hits = re.findall(
        r"\b(oi|opa|ola|olá|tudo bem|beleza|valeu|obrigado|obrigada|arquitetura|quem|qual|quais|como|voce|você|"
        r"fale|sobre|portfolio|portfólio|experiencia|experiência|trajetoria|trajetória|contratar|principio|princípio|"
        r"nao-deterministico|não-determinístico|memoria|memória|cartuchos|navegador|baixa|projeto|criou|conhecimentos|"
        r"entrar|contato|bom dia|boa tarde|boa noite|porém|enquanto|estabelece|provam|prova|segundo|direito|dados|"
        r"usado|prática|cerca|quanto|vezes|não|já|posso|recomenda)\b",
        lower,
    )
    en_hits = re.findall(
        r"\b(who|what|how|why|where|when|explain|tell|state|does|your|role|this|background|career|slash|stream|"
        r"hire|about|principle|theorem|space|classes|thermal|under|tools|built|cutoff|general|knowledge|hello|"
        r"thanks|however|while|establish|prove|applied|used|practice|best|should)\b",
        lower,
    )
    es_hits = re.findall(
        r"\b(quien|quién|cual|cuál|cuales|cuáles|como|cómo|que|qué|explica|explicame|explícame|hablame|háblame|"
        r"portafolio|experiencia|trayectoria|correo|contratar|principio|teorema|complejidad|no determinista|conteo|"
        r"interactua|interactúa|navegador|herramientas|creo|creó|aprendizaje|refuerzo|hola|buenos|gracias|mientras|"
        r"mediante|establece|establecen|demuestra|demuestran|segun|según|donde|dónde|debo)\b",
        lower,
    )
    fr_hits = re.findall(
        r"\b(qui|quel|quelle|quels|quelles|comment|expliquez|parlez|votre|nom|sur|parcours|recruter|principe|"
        r"theoreme|théorème|theoremes|théorèmes|demontre|démontre|demontrent|démontrent|etablit|établit|etablissent|"
        r"établissent|selon|classes|réutilisation|reutilisation|navigateur|cartouches|connaissances|outils|crees|"
        r"créés|systeme|système|bonjour|merci|tandis|dans|avec|pour|est|sont|etes|êtes|recommandez)\b",
        lower,
    )

    scores["pt"] += len(pt_hits) * 2.2
    scores["en"] += len(en_hits) * 2.2
    scores["es"] += len(es_hits) * 2.2
    scores["fr"] += len(fr_hits) * 2.2

    if re.search(r"\b(o|os|um|uma|do|da|dos|das|no|na|pelo|pela|dele|neste|são|então)\b", lower):
        scores["pt"] += 2.6
    if re.search(r"\b(el|los|las|un|una|del|en el|en la|este|cuáles|están|también)\b", lower):
        scores["es"] += 2.6
    if re.search(r"\b(le|les|des|du|une|dans|ce|cette|ces|aux)\b", lower):
        scores["fr"] += 2.4
    if re.search(r"\b(the|and|for|with|from|into|is|are)\b", lower):
        scores["en"] += 2.2

    best_lang = fb
    best_score = 0.0
    for cand in ("pt", "en", "es", "fr"):
        if scores[cand] > best_score:
            best_score = scores[cand]
            best_lang = cand
    return best_lang if best_score > 0.0 else fb


def select_out_of_cone_epistemic_gate(user_query: str, fallback_lang: str = "en") -> str:
    """Selects the localized out-of-cone epistemic guard prompt (`pt`, `en`, `es`, `fr`)."""
    lang = detect_polyglot_query_lang(user_query, fallback=fallback_lang)
    if is_pure_conversational_greeting(user_query):
        return OUT_OF_CONE_GREETING_GATES[lang]
    return OUT_OF_CONE_EPISTEMIC_GATES[lang]


def _align16(n: int) -> int:
    return (int(n) + 15) & ~15


@dataclass
class WebGPUExportReport:
    """Summary of an exported self-contained WebGPU `MoS + SCache O(1) + ScarStore` bundle."""

    model_id: str
    output_dir: str
    hidden_dim: int
    num_layers: int
    num_q_heads: int
    num_kv_heads: int
    head_dim: int
    intermediate_size: int
    vocab_size: int
    mos_rank: int
    num_shards: int
    max_shard_mib: float
    total_weights_mib: float
    under_128mib_universal_limit: bool
    scarstore_capsules: int
    scarstore_record_bytes: int
    export_seconds: float


@dataclass
class WebGPUGenerationResult:
    """End-to-end telemetry from native WGSL (`wgpu-py`) execution on physical GPU hardware."""

    prompt: str
    answer: str
    generated_token_ids: List[int]
    prefill_tokens: int
    generated_tokens: int
    prefill_ms: float
    decode_ms: float
    decode_tok_per_s: float
    adapter_name: str
    backend_type: str
    scache_bytes_initial: int
    scache_bytes_after_prefill: int
    scache_bytes_after_decode: int
    scache_delta_bytes: int
    vram_weights_mib: float
    active_capsules: List[str] = field(default_factory=list)
    active_gates: Dict[str, float] = field(default_factory=dict)
    http206_bytes_fetched: int = 0
    mean_confidence_p1: float = 0.0
    mean_margin_p1_p2: float = 0.0
    max_inter_head_spread: float = 0.0
    epistemic_mode: str = "base_trunk"


class _ShardBuilder:
    """Accumulates 16-byte-aligned tensor byte blobs into `<= max_shard_bytes` `.bin` files."""

    def __init__(self, out_dir: Path, prefix: str, max_shard_bytes: int = DEFAULT_MAX_SHARD_BYTES) -> None:
        self.out_dir = out_dir
        self.prefix = prefix
        self.max_shard_bytes = int(max_shard_bytes)
        self.shards: List[Dict[str, Any]] = []
        self._cur_buf = bytearray()
        self._cur_idx = 0

    def _flush_current(self) -> None:
        if not self._cur_buf:
            return
        pad = _align16(len(self._cur_buf)) - len(self._cur_buf)
        if pad:
            self._cur_buf.extend(b"\x00" * pad)
        fname = f"{self.prefix}_{self._cur_idx:02d}.bin"
        fpath = self.out_dir / fname
        fpath.write_bytes(self._cur_buf)
        self.shards.append(
            {
                "shard_index": len(self.shards),
                "filename": fname,
                "byte_length": len(self._cur_buf),
                "mib": round(len(self._cur_buf) / (1024.0 * 1024.0), 4),
            }
        )
        self._cur_buf = bytearray()
        self._cur_idx += 1

    def ensure_capacity_for_group(self, group_bytes: int) -> int:
        if self._cur_buf and (len(self._cur_buf) + group_bytes > self.max_shard_bytes):
            self._flush_current()
        return len(self.shards)

    def append_blob(self, raw: bytes) -> Tuple[int, int]:
        """Appends `raw` at a 16-byte aligned offset and returns `(shard_idx, u32_word_offset)`."""
        aligned_cur = _align16(len(self._cur_buf))
        if aligned_cur > len(self._cur_buf):
            self._cur_buf.extend(b"\x00" * (aligned_cur - len(self._cur_buf)))
        u32_off = len(self._cur_buf) // 4
        self._cur_buf.extend(raw)
        pad = _align16(len(self._cur_buf)) - len(self._cur_buf)
        if pad:
            self._cur_buf.extend(b"\x00" * pad)
        return len(self.shards), u32_off

    def finalize(self) -> List[Dict[str, Any]]:
        self._flush_current()
        return self.shards


def _resolve_default_scarstore_for_dim(hidden_dim: int) -> Optional[Path]:
    repo_root = Path(__file__).resolve().parents[1]
    online_dir = repo_root / "results" / "online_library_v3_0"
    cache_dir = Path.home() / ".cache" / "mixture_of_scars" / "scarstore"
    candidates: List[Path] = []
    if int(hidden_dim) == 896:
        candidates = [
            online_dir / "qwen0p5b_universal_v4_0.scarstore",
            cache_dir / "qwen0p5b_universal_v4_0.scarstore",
            online_dir / "qwen0p5b_v3_0.scarstore",
            cache_dir / "qwen0p5b_v3_0.scarstore",
            cache_dir / "qwen0p5b_v3_0.shell.scarstore",
        ]
    elif int(hidden_dim) == 2048:
        candidates = [
            online_dir / "qwen3b_universal_v4_0.scarstore",
            cache_dir / "qwen3b_universal_v4_0.scarstore",
            online_dir / "qwen3b_v3_0.scarstore",
            cache_dir / "qwen3b_v3_0.scarstore",
            cache_dir / "qwen3b_v3_0.shell.scarstore",
        ]
    for c in candidates:
        if c.exists():
            return c
    return None


def export_scarstore_for_webgpu(
    store_path: Union[str, Path],
    output_dir: Union[str, Path],
    copy_payload_store: bool = True,
    remote_store_url: Optional[str] = None,
) -> Dict[str, Any]:
    """Exports compact `< 45 KB` browser router index (`scarstore_router.json` + `.bin`) + `.scarstore` Range target."""
    import torch
    import torch.nn.functional as F

    from scar_cache.cli_scar_store import resolve_official_cloud_tier
    from scar_cache.head_expanded_attention import HeadExpandedScarStore

    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    store = HeadExpandedScarStore.open(store_path)
    try:
        summary = store.inspect_summary()
        is_v4 = summary.get("format") == "GoldenSliceScarStoreV4"
        d = store.hidden_dim
        n_heads = store.num_heads
        d_head = store.head_dim

        slots_by_cid = {s["capsule_id"]: s for s in summary["slots"]}
        capsules_manifest: List[Dict[str, Any]] = []
        z_rows: List[torch.Tensor] = []

        seen_cids: set[str] = set()
        ordered_entries: List[Dict[str, Any]] = []
        for s in summary["slots"]:
            ordered_entries.append(s)
            seen_cids.add(s["capsule_id"])
        for g in summary.get("cloud_directory", []):
            if g["capsule_id"] not in seen_cids:
                ordered_entries.append(g)
                seen_cids.add(g["capsule_id"])

        for idx, entry in enumerate(ordered_entries):
            cid = str(entry["capsule_id"])
            s_info = slots_by_cid.get(cid)
            if s_info is not None and int(s_info["slot_idx"]) < int(store.z_anchors_installed.shape[0]):
                s_idx = int(s_info["slot_idx"])
                z_vec = F.normalize(store.z_anchors_installed[s_idx].detach().cpu().float(), dim=-1, eps=1e-8)
                byte_offset = int(s_info["byte_offset"])
                local_ready = bool(s_info["bitmap_present"] and not s_info["payload_all_zero_wiped"])
            else:
                s_idx = int(entry.get("slot_idx", idx))
                z_vec = torch.zeros((d,), dtype=torch.float32)
                byte_offset = int(store.payload_offset + s_idx * store.record_bytes)
                local_ready = False

            z_rows.append(z_vec)
            capsules_manifest.append(
                {
                    "index": idx,
                    "capsule_id": cid,
                    "slot_idx": int(entry.get("slot_idx", idx)),
                    "coord": list(entry["coord"]),
                    "byte_offset": byte_offset,
                    "record_bytes": int(store.record_bytes),
                    "record_kb": round(store.record_bytes / 1024.0, 2),
                    "local_store_has_bytes": local_ready,
                    "tau": float(entry["tau"]),
                    "ramp": float(entry["ramp"]),
                    "parent_capsules": list(entry.get("parent_capsules", [])),
                    "metadata": dict(entry.get("metadata", {})),
                }
            )

        z_mat = (
            torch.stack(z_rows, dim=0).to(torch.float32).contiguous()
            if z_rows
            else torch.empty((0, d), dtype=torch.float32)
        )

        if is_v4:
            mu_qm = store.mu_query_mid.detach().cpu().to(torch.float32).contiguous()  # type: ignore[attr-defined]
            mu_hm = store.mu_hidden_mid.detach().cpu().to(torch.float32).contiguous()  # type: ignore[attr-defined]
            mu_hf = store.mu_hidden_final.detach().cpu().to(torch.float32).contiguous()
            u_lang = store.u_lang_mid.detach().cpu().to(torch.float32).reshape(-1).contiguous()  # type: ignore[attr-defined]
            k_lang = int(store.k_lang)  # type: ignore[attr-defined]
            router_bin_parts = [
                mu_qm.numpy().tobytes(),
                mu_hm.numpy().tobytes(),
                mu_hf.numpy().tobytes(),
                u_lang.numpy().tobytes(),
                z_mat.numpy().tobytes(),
            ]
            bin_layout = {
                "mu_query_mid": {"offset_floats": 0, "length_floats": d},
                "mu_hidden_mid": {"offset_floats": d, "length_floats": d},
                "mu_hidden_final": {"offset_floats": 2 * d, "length_floats": d},
                "u_lang_mid": {"offset_floats": 3 * d, "length_floats": d * k_lang},
                "z_anchors": {"offset_floats": 3 * d + d * k_lang, "length_floats": len(capsules_manifest) * d},
            }
        else:
            mu_ql = store.mu_query_last.detach().cpu().to(torch.float32).contiguous()
            mu_hf = store.mu_hidden_final.detach().cpu().to(torch.float32).contiguous()
            mu_qh = store.mu_q_heads.detach().cpu().to(torch.float32).reshape(-1).contiguous()
            router_bin_parts = [
                mu_ql.numpy().tobytes(),
                mu_hf.numpy().tobytes(),
                mu_qh.numpy().tobytes(),
                z_mat.numpy().tobytes(),
            ]
            bin_layout = {
                "mu_query_last": {"offset_floats": 0, "length_floats": d},
                "mu_hidden_final": {"offset_floats": d, "length_floats": d},
                "mu_q_heads": {"offset_floats": 2 * d, "length_floats": n_heads * d_head},
                "z_anchors": {"offset_floats": 2 * d + n_heads * d_head, "length_floats": len(capsules_manifest) * d},
            }

        router_bin = b"".join(router_bin_parts)
        router_bin_path = out_dir / "scarstore_router.bin"
        router_bin_path.write_bytes(router_bin)

        if remote_store_url is None:
            try:
                cloud_spec = resolve_official_cloud_tier(hidden_dim=d)
                remote_store_url = str(cloud_spec["store_url"])
            except ValueError:
                remote_store_url = None

        local_store_filename: Optional[str] = None
        if copy_payload_store and Path(store_path).exists():
            local_store_filename = "capsules.scarstore"
            dst_store = out_dir / local_store_filename
            if Path(store_path).resolve() != dst_store.resolve():
                shutil.copy2(store_path, dst_store)

        if is_v4:
            router_json: Dict[str, Any] = {
                "format": "WebGPUScarStoreRouterV1",
                "version": "4.0.0",
                "routing_architecture": "golden_slice_v4",
                "hidden_dim": d,
                "num_layers": int(getattr(store, "num_layers", 24)),
                "mid_layer_idx": int(store.mid_layer_idx),  # type: ignore[attr-defined]
                "num_heads": n_heads,
                "head_dim": d_head,
                "rank_mid": int(store.rank_mid),  # type: ignore[attr-defined]
                "rank_final": int(store.rank_final),  # type: ignore[attr-defined]
                "rank": int(store.rank),
                "num_key_prototypes": 0,
                "attention_beta": 0.0,
                "k_lang": int(store.k_lang),  # type: ignore[attr-defined]
                "seed_horizon": int(getattr(store, "seed_horizon", 44)),
                "seed_fade_steps": int(getattr(store, "seed_fade_steps", 16)),
                "winner_margin": float(getattr(store, "winner_margin", 0.0002)),
                "record_bytes": int(store.record_bytes),
                "record_kb": round(store.record_bytes / 1024.0, 2),
                "payload_offset": int(store.payload_offset),
                "user_turn_prefix_ids": list(store.user_turn_prefix_ids or [151644, 872, 198]),
                "user_turn_suffix_ids": list(
                    getattr(store, "user_turn_suffix_ids", None) or [151645, 198, 151644, 77091, 198]
                ),
                "routing_mode": "span_max",
                "span_window": 10,
                "span_stride": 3,
                "router_bin_file": "scarstore_router.bin",
                "router_bin_bytes": len(router_bin),
                "router_bin_layout": bin_layout,
                "local_http206_store_url": local_store_filename,
                "cloud_http206_store_url": remote_store_url,
                "num_capsules": len(capsules_manifest),
                "capsules": capsules_manifest,
            }
        else:
            router_json = {
                "format": "WebGPUScarStoreRouterV1",
                "version": "3.0.0",
                "routing_architecture": "head_expanded_v3",
                "hidden_dim": d,
                "num_heads": n_heads,
                "head_dim": d_head,
                "rank": int(store.rank),
                "num_key_prototypes": int(store.num_key_prototypes),
                "attention_beta": float(store.attention_beta),
                "record_bytes": int(store.record_bytes),
                "record_kb": round(store.record_bytes / 1024.0, 2),
                "payload_offset": int(store.payload_offset),
                "user_turn_prefix_ids": list(store.user_turn_prefix_ids or [151644, 872, 198]),
                "routing_mode": "span_max",
                "span_window": 10,
                "span_stride": 3,
                "router_bin_file": "scarstore_router.bin",
                "router_bin_bytes": len(router_bin),
                "router_bin_layout": bin_layout,
                "local_http206_store_url": local_store_filename,
                "cloud_http206_store_url": remote_store_url,
                "num_capsules": len(capsules_manifest),
                "capsules": capsules_manifest,
            }
        (out_dir / "scarstore_router.json").write_text(
            json.dumps(router_json, indent=2, ensure_ascii=False), encoding="utf-8"
        )
        return router_json
    finally:
        store.close()


def export_mos_model_to_webgpu(
    model_id_or_path: str = "Qwen/Qwen2.5-0.5B-Instruct",
    output_dir: Union[str, Path] = "./webgpu_dist/qwen0p5b",
    scarstore_path: Optional[Union[str, Path]] = None,
    mos_rank: int = 128,
    max_shard_bytes: int = DEFAULT_MAX_SHARD_BYTES,
    copy_scarstore_payload: bool = True,
    local_files_only: bool = False,
) -> WebGPUExportReport:
    """Exports an `MoS INT4+ASVD` CausalLM + `HeadExpandedScarStore` into `< 80 MiB` WebGPU binary shards."""
    from safetensors import safe_open
    import torch
    from transformers import AutoConfig, AutoTokenizer

    from scar_cache.mos_student import (
        _default_mos_cache_dir,
        quantize_2d_block64_int4,
        transcode_hf_student_to_mos_safetensors,
    )

    t0 = time.perf_counter()
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    cand_path = Path(model_id_or_path)
    if cand_path.is_dir() and (cand_path / "mos_student.safetensors").exists():
        mos_dir = cand_path
    else:
        mos_dir = _default_mos_cache_dir(str(model_id_or_path), rank=mos_rank)
        if not (mos_dir / "mos_student.safetensors").exists():
            transcode_hf_student_to_mos_safetensors(
                model_id_or_path=str(model_id_or_path),
                out_safetensors_path=mos_dir / "mos_student.safetensors",
                rank=mos_rank,
                local_files_only=local_files_only,
            )
            cfg_dl = AutoConfig.from_pretrained(model_id_or_path, local_files_only=local_files_only)
            tok_dl = AutoTokenizer.from_pretrained(model_id_or_path, local_files_only=local_files_only)
            cfg_dl.save_pretrained(mos_dir)
            tok_dl.save_pretrained(mos_dir)

    cfg = AutoConfig.from_pretrained(mos_dir if (mos_dir / "config.json").exists() else model_id_or_path, local_files_only=True)
    tok_src = mos_dir if (mos_dir / "tokenizer.json").exists() else model_id_or_path
    tok = AutoTokenizer.from_pretrained(tok_src, local_files_only=local_files_only)
    tok.save_pretrained(out_dir)

    # Copy canonical WGSL shader + static web app files so `out_dir` can also be hosted standalone anywhere
    shutil.copy2(WGSL_KERNELS_PATH, out_dir / "mos_scache_kernels.wgsl")
    if WEBGPU_APP_DIR.is_dir():
        for app_file in WEBGPU_APP_DIR.iterdir():
            if app_file.is_file():
                shutil.copy2(app_file, out_dir / app_file.name)

    hidden_dim = int(cfg.hidden_size)
    num_layers = int(cfg.num_hidden_layers)
    num_q_heads = int(cfg.num_attention_heads)
    num_kv_heads = int(getattr(cfg, "num_key_value_heads", num_q_heads))
    head_dim = hidden_dim // num_q_heads
    inter_dim = int(cfg.intermediate_size)
    vocab_size = int(cfg.vocab_size)
    rms_norm_eps = float(getattr(cfg, "rms_norm_eps", 1e-6))
    rope_theta = float(getattr(cfg, "rope_theta", 1000000.0))
    tie_embeddings = bool(getattr(cfg, "tie_word_embeddings", True))

    sf_path = mos_dir / "mos_student.safetensors"
    builder = _ShardBuilder(out_dir=out_dir, prefix="mos_shard", max_shard_bytes=max_shard_bytes)

    vocab_chunks_meta: List[Dict[str, Any]] = []
    lm_head_chunks_meta: List[Dict[str, Any]] = []
    layers_meta: List[Dict[str, Any]] = []

    with safe_open(str(sf_path), framework="pt", device="cpu") as sf:
        all_keys = set(sf.keys())

        # 1. Quantize `embed_tokens` in Block-64 INT4 chunks (< 80 MiB per chunk -> universal WebGPU safe!)
        if "model.embed_tokens.packed_u8" in all_keys and "model.embed_tokens.scales_f16" in all_keys:
            emb_pk_full = sf.get_tensor("model.embed_tokens.packed_u8").contiguous()
            emb_sc_full = sf.get_tensor("model.embed_tokens.scales_f16").to(torch.float16).contiguous()
            actual_vocab = int(emb_pk_full.shape[0])
            vocab_size = actual_vocab
            bytes_per_vocab_row = (hidden_dim // 2) + (hidden_dim // 64) * 2
            max_rows_per_chunk = min(actual_vocab, max(4096, (max_shard_bytes - 65536) // bytes_per_vocab_row))
            for v_start in range(0, actual_vocab, max_rows_per_chunk):
                v_end = min(actual_vocab, v_start + max_rows_per_chunk)
                v_rows = v_end - v_start
                pk_b = emb_pk_full[v_start:v_end].contiguous().numpy().tobytes()
                sc_b = emb_sc_full[v_start:v_end].contiguous().numpy().tobytes()
                builder.ensure_capacity_for_group(len(pk_b) + len(sc_b) + 64)
                s_idx, pk_u32 = builder.append_blob(pk_b)
                s_idx2, sc_u32 = builder.append_blob(sc_b)
                assert s_idx == s_idx2
                vocab_chunks_meta.append(
                    {
                        "shard_index": s_idx,
                        "vocab_start": v_start,
                        "vocab_rows": v_rows,
                        "packed_u32_off": pk_u32,
                        "scales_u32_off": sc_u32,
                    }
                )
            del emb_pk_full, emb_sc_full
        else:
            emb_w = sf.get_tensor("model.embed_tokens.weight").to(torch.float32)
            actual_vocab = int(emb_w.shape[0])
            vocab_size = actual_vocab
            # At d=896, 151936 rows is 68.97 MiB (< 80 MiB -> 1 single shard!); at d=2048, split into <=44 MiB shards!
            bytes_per_vocab_row = (hidden_dim // 2) + (hidden_dim // 64) * 2
            max_rows_per_chunk = min(actual_vocab, max(4096, (max_shard_bytes - 65536) // bytes_per_vocab_row))

            for v_start in range(0, actual_vocab, max_rows_per_chunk):
                v_end = min(actual_vocab, v_start + max_rows_per_chunk)
                v_rows = v_end - v_start
                pk, sc = quantize_2d_block64_int4(emb_w[v_start:v_end])
                pk_b = pk.contiguous().numpy().tobytes()
                sc_b = sc.contiguous().numpy().tobytes()
                builder.ensure_capacity_for_group(len(pk_b) + len(sc_b) + 64)
                s_idx, pk_u32 = builder.append_blob(pk_b)
                s_idx2, sc_u32 = builder.append_blob(sc_b)
                assert s_idx == s_idx2
                chunk_entry = {
                    "shard_index": s_idx,
                    "vocab_start": v_start,
                    "vocab_rows": v_rows,
                    "packed_u32_off": pk_u32,
                    "scales_u32_off": sc_u32,
                }
                vocab_chunks_meta.append(chunk_entry)
            del emb_w

        if tie_embeddings or (
            "lm_head.weight" not in all_keys and "lm_head.packed_u8" not in all_keys
        ):
            lm_head_chunks_meta = list(vocab_chunks_meta)
        elif "lm_head.packed_u8" in all_keys and "lm_head.scales_f16" in all_keys:
            lm_pk_full = sf.get_tensor("lm_head.packed_u8").contiguous()
            lm_sc_full = sf.get_tensor("lm_head.scales_f16").to(torch.float16).contiguous()
            for v_start in range(0, actual_vocab, max_rows_per_chunk):
                v_end = min(actual_vocab, v_start + max_rows_per_chunk)
                v_rows = v_end - v_start
                pk_b = lm_pk_full[v_start:v_end].contiguous().numpy().tobytes()
                sc_b = lm_sc_full[v_start:v_end].contiguous().numpy().tobytes()
                builder.ensure_capacity_for_group(len(pk_b) + len(sc_b) + 64)
                s_idx, pk_u32 = builder.append_blob(pk_b)
                s_idx2, sc_u32 = builder.append_blob(sc_b)
                assert s_idx == s_idx2
                lm_head_chunks_meta.append(
                    {
                        "shard_index": s_idx,
                        "vocab_start": v_start,
                        "vocab_rows": v_rows,
                        "packed_u32_off": pk_u32,
                        "scales_u32_off": sc_u32,
                    }
                )
            del lm_pk_full, lm_sc_full
        else:
            lm_w = sf.get_tensor("lm_head.weight").to(torch.float32)
            for v_start in range(0, actual_vocab, max_rows_per_chunk):
                v_end = min(actual_vocab, v_start + max_rows_per_chunk)
                v_rows = v_end - v_start
                pk, sc = quantize_2d_block64_int4(lm_w[v_start:v_end])
                pk_b = pk.contiguous().numpy().tobytes()
                sc_b = sc.contiguous().numpy().tobytes()
                builder.ensure_capacity_for_group(len(pk_b) + len(sc_b) + 64)
                s_idx, pk_u32 = builder.append_blob(pk_b)
                s_idx2, sc_u32 = builder.append_blob(sc_b)
                assert s_idx == s_idx2
                lm_head_chunks_meta.append(
                    {
                        "shard_index": s_idx,
                        "vocab_start": v_start,
                        "vocab_rows": v_rows,
                        "packed_u32_off": pk_u32,
                        "scales_u32_off": sc_u32,
                    }
                )
            del lm_w

        # Start a fresh shard stream for Transformer layers so embed & layer buffers stay cleanly separated
        builder._flush_current()

        def _collect_linear_blobs(prefix_key: str) -> Tuple[str, Dict[str, bytes], Tuple[int, int, int]]:
            bias_b = b""
            if f"{prefix_key}.bias" in all_keys:
                bias_b = sf.get_tensor(f"{prefix_key}.bias").to(torch.float16).contiguous().numpy().tobytes()
            if f"{prefix_key}.vq_codes_u8" in all_keys:
                vc_t = sf.get_tensor(f"{prefix_key}.vq_codes_u8").contiguous()
                vs_t = sf.get_tensor(f"{prefix_key}.vq_scales_f16").to(torch.float16).contiguous()
                lut_t = sf.get_tensor(f"{prefix_key}.lut256_f16").to(torch.float16).contiguous()
                deq_t = sf.get_tensor(f"{prefix_key}.d_eq_f16").to(torch.float16).contiguous()
                out_d = int(vc_t.shape[0])
                in_d = int(vc_t.shape[1]) * 4
                blobs = {
                    "vq_codes": vc_t.numpy().tobytes(),
                    "vq_scales": vs_t.numpy().tobytes(),
                    "lut256": lut_t.numpy().tobytes(),
                    "d_eq": deq_t.numpy().tobytes(),
                }
                r_d = 0
                if f"{prefix_key}.a_scar_packed_u8" in all_keys and f"{prefix_key}.b_scar_packed_u8" in all_keys:
                    ap_t = sf.get_tensor(f"{prefix_key}.a_scar_packed_u8").contiguous()
                    as_t = sf.get_tensor(f"{prefix_key}.a_scar_scales_f16").to(torch.float16).contiguous()
                    bp_t = sf.get_tensor(f"{prefix_key}.b_scar_packed_u8").contiguous()
                    bs_t = sf.get_tensor(f"{prefix_key}.b_scar_scales_f16").to(torch.float16).contiguous()
                    r_d = int(ap_t.shape[0])
                    blobs["ascar_packed"] = ap_t.numpy().tobytes()
                    blobs["ascar_scales"] = as_t.numpy().tobytes()
                    blobs["bscar_combined"] = bp_t.numpy().tobytes() + bs_t.numpy().tobytes()
                if bias_b:
                    blobs["bias"] = bias_b
                return "vq4_scar", blobs, (out_d, in_d, r_d)
            if f"{prefix_key}.prot_packed_u8" in all_keys:
                pk_t = sf.get_tensor(f"{prefix_key}.prot_packed_u8").contiguous()
                sc_t = sf.get_tensor(f"{prefix_key}.prot_scales_f16").to(torch.float16).contiguous()
                out_d = int(pk_t.shape[0])
                in_d = int(pk_t.shape[1]) * 2
                blobs = {
                    "packed": pk_t.numpy().tobytes(),
                    "scales": sc_t.numpy().tobytes(),
                }
                if f"{prefix_key}.d_eq_f16" in all_keys:
                    deq_t = sf.get_tensor(f"{prefix_key}.d_eq_f16").to(torch.float16).contiguous()
                    blobs["d_eq"] = deq_t.numpy().tobytes()
                r_d = 0
                if f"{prefix_key}.a_scar_packed_u8" in all_keys and f"{prefix_key}.b_scar_packed_u8" in all_keys:
                    ap_t = sf.get_tensor(f"{prefix_key}.a_scar_packed_u8").contiguous()
                    as_t = sf.get_tensor(f"{prefix_key}.a_scar_scales_f16").to(torch.float16).contiguous()
                    bp_t = sf.get_tensor(f"{prefix_key}.b_scar_packed_u8").contiguous()
                    bs_t = sf.get_tensor(f"{prefix_key}.b_scar_scales_f16").to(torch.float16).contiguous()
                    r_d = int(ap_t.shape[0])
                    blobs["ascar_packed"] = ap_t.numpy().tobytes()
                    blobs["ascar_scales"] = as_t.numpy().tobytes()
                    blobs["bscar_combined"] = bp_t.numpy().tobytes() + bs_t.numpy().tobytes()
                if bias_b:
                    blobs["bias"] = bias_b
                return "prot_int4_scar", blobs, (out_d, in_d, r_d)
            if f"{prefix_key}.packed_base" in all_keys:
                pk_t = sf.get_tensor(f"{prefix_key}.packed_base").contiguous()
                sc_t = sf.get_tensor(f"{prefix_key}.scales_base").to(torch.float16).contiguous()
                a_t = sf.get_tensor(f"{prefix_key}.A_scar").to(torch.float16).contiguous()
                b_t = sf.get_tensor(f"{prefix_key}.B_scar").to(torch.float16).contiguous()
                out_d, r_d = int(b_t.shape[0]), int(b_t.shape[1])
                in_d = int(a_t.shape[1])
                blobs = {
                    "packed": pk_t.numpy().tobytes(),
                    "scales": sc_t.numpy().tobytes(),
                    "A_scar": a_t.numpy().tobytes(),
                    "B_scar": b_t.numpy().tobytes(),
                }
                if bias_b:
                    blobs["bias"] = bias_b
                return "mos_int4_asvd", blobs, (out_d, in_d, r_d)
            w_t = sf.get_tensor(f"{prefix_key}.weight").to(torch.float16).contiguous()
            out_d, in_d = int(w_t.shape[0]), int(w_t.shape[1])
            blobs = {"weight": w_t.numpy().tobytes()}
            if bias_b:
                blobs["bias"] = bias_b
            return "fp16", blobs, (out_d, in_d, 0)

        for l_idx in range(num_layers):
            pfx = f"model.layers.{l_idx}"
            ln1_b = sf.get_tensor(f"{pfx}.input_layernorm.weight").to(torch.float16).contiguous().numpy().tobytes()
            ln2_b = sf.get_tensor(f"{pfx}.post_attention_layernorm.weight").to(torch.float16).contiguous().numpy().tobytes()

            proj_specs: Dict[str, Tuple[str, Dict[str, bytes], Tuple[int, int, int]]] = {}
            layer_total_bytes = len(ln1_b) + len(ln2_b) + 256
            for sec, pname in (
                ("self_attn", "q_proj"),
                ("self_attn", "k_proj"),
                ("self_attn", "v_proj"),
                ("self_attn", "o_proj"),
                ("mlp", "gate_proj"),
                ("mlp", "up_proj"),
                ("mlp", "down_proj"),
            ):
                mode, blobs, dims = _collect_linear_blobs(f"{pfx}.{sec}.{pname}")
                proj_specs[f"{sec}.{pname}"] = (mode, blobs, dims)
                layer_total_bytes += sum(_align16(len(v)) for v in blobs.values())

            shard_idx = builder.ensure_capacity_for_group(layer_total_bytes)
            s_a, ln1_u32 = builder.append_blob(ln1_b)
            s_b, ln2_u32 = builder.append_blob(ln2_b)
            assert s_a == shard_idx and s_b == shard_idx

            layer_rec: Dict[str, Any] = {
                "layer_index": l_idx,
                "shard_index": shard_idx,
                "input_layernorm_u32_off": ln1_u32,
                "post_attention_layernorm_u32_off": ln2_u32,
                "projections": {},
            }
            for full_name, (mode, blobs, (out_d, in_d, r_d)) in proj_specs.items():
                has_bias = 1 if "bias" in blobs else 0
                bias_u32 = 0
                if has_bias:
                    _, bias_u32 = builder.append_blob(blobs["bias"])
                if mode == "vq4_scar":
                    _, vc_u32 = builder.append_blob(blobs["vq_codes"])
                    _, vs_u32 = builder.append_blob(blobs["vq_scales"])
                    _, lut_u32 = builder.append_blob(blobs["lut256"])
                    _, deq_u32 = builder.append_blob(blobs["d_eq"])
                    ap_u32 = as_u32 = bs_comb_u32 = 0
                    if r_d > 0:
                        _, ap_u32 = builder.append_blob(blobs["ascar_packed"])
                        _, as_u32 = builder.append_blob(blobs["ascar_scales"])
                        _, bs_comb_u32 = builder.append_blob(blobs["bscar_combined"])
                    layer_rec["projections"][full_name] = {
                        "mode": "vq4_scar",
                        "out_dim": out_d,
                        "in_dim": in_d,
                        "rank": r_d,
                        "vq_codes_u32_off": vc_u32,
                        "vq_scales_u32_off": vs_u32,
                        "lut256_u32_off": lut_u32,
                        "d_eq_u32_off": deq_u32,
                        "ascar_packed_u32_off": ap_u32,
                        "ascar_scales_u32_off": as_u32,
                        "bscar_u32_off": bs_comb_u32,
                        "bias_u32_off": bias_u32,
                        "has_bias": has_bias,
                    }
                elif mode == "prot_int4_scar":
                    _, pk_u32 = builder.append_blob(blobs["packed"])
                    _, sc_u32 = builder.append_blob(blobs["scales"])
                    has_deq = 1 if "d_eq" in blobs else 0
                    deq_u32 = 0
                    if has_deq:
                        _, deq_u32 = builder.append_blob(blobs["d_eq"])
                    ap_u32 = as_u32 = bs_comb_u32 = 0
                    if r_d > 0:
                        _, ap_u32 = builder.append_blob(blobs["ascar_packed"])
                        _, as_u32 = builder.append_blob(blobs["ascar_scales"])
                        _, bs_comb_u32 = builder.append_blob(blobs["bscar_combined"])
                    layer_rec["projections"][full_name] = {
                        "mode": "prot_int4_scar",
                        "out_dim": out_d,
                        "in_dim": in_d,
                        "rank": r_d,
                        "packed_u32_off": pk_u32,
                        "scales_u32_off": sc_u32,
                        "d_eq_u32_off": deq_u32,
                        "has_d_eq": has_deq,
                        "ascar_packed_u32_off": ap_u32,
                        "ascar_scales_u32_off": as_u32,
                        "bscar_u32_off": bs_comb_u32,
                        "bias_u32_off": bias_u32,
                        "has_bias": has_bias,
                    }
                elif mode == "mos_int4_asvd":
                    _, pk_u32 = builder.append_blob(blobs["packed"])
                    _, sc_u32 = builder.append_blob(blobs["scales"])
                    _, a_u32 = builder.append_blob(blobs["A_scar"])
                    _, b_u32 = builder.append_blob(blobs["B_scar"])
                    layer_rec["projections"][full_name] = {
                        "mode": "mos_int4_asvd",
                        "out_dim": out_d,
                        "in_dim": in_d,
                        "rank": r_d,
                        "packed_u32_off": pk_u32,
                        "scales_u32_off": sc_u32,
                        "ascar_u32_off": a_u32,
                        "bscar_u32_off": b_u32,
                        "bias_u32_off": bias_u32,
                        "has_bias": has_bias,
                    }
                else:
                    _, w_u32 = builder.append_blob(blobs["weight"])
                    layer_rec["projections"][full_name] = {
                        "mode": "fp16",
                        "out_dim": out_d,
                        "in_dim": in_d,
                        "w_u32_off": w_u32,
                        "bias_u32_off": bias_u32,
                        "has_bias": has_bias,
                    }
            layers_meta.append(layer_rec)

        final_norm_b = sf.get_tensor("model.norm.weight").to(torch.float16).contiguous().numpy().tobytes()
        builder.ensure_capacity_for_group(len(final_norm_b) + 64)
        fn_shard_idx, fn_u32_off = builder.append_blob(final_norm_b)

    shards_manifest = builder.finalize()
    max_shard_b = max((s["byte_length"] for s in shards_manifest), default=0)
    total_b = sum(s["byte_length"] for s in shards_manifest)

    # Export ScarStore router + HTTP 206 Range target if available
    resolved_store = Path(scarstore_path) if scarstore_path is not None else _resolve_default_scarstore_for_dim(hidden_dim)
    scarstore_info: Optional[Dict[str, Any]] = None
    if resolved_store is not None and resolved_store.exists():
        scarstore_info = export_scarstore_for_webgpu(
            store_path=resolved_store,
            output_dir=out_dir,
            copy_payload_store=copy_scarstore_payload,
        )

    # Exact RoPE inverse frequencies in FP32 for IEEE-754 parity across JS and Python
    inv_freq = [1.0 / (rope_theta ** (float(2 * j) / float(head_dim))) for j in range(head_dim // 2)]

    eos_ids: List[int] = []
    for cand_tok in ("<|im_end|>", "<|endoftext|>"):
        tid = tok.convert_tokens_to_ids(cand_tok)
        if isinstance(tid, int) and tid >= 0 and tid not in eos_ids:
            eos_ids.append(tid)
    if getattr(cfg, "eos_token_id", None) is not None:
        raw_eos = cfg.eos_token_id if isinstance(cfg.eos_token_id, list) else [cfg.eos_token_id]
        for eid in raw_eos:
            if int(eid) not in eos_ids:
                eos_ids.append(int(eid))

    manifest = {
        "format": "MoSWebGPUEngineV1",
        "version": "3.0.0",
        "model_id": str(model_id_or_path),
        "wgsl_shader": "mos_scache_kernels.wgsl",
        "tokenizer_file": "tokenizer.json",
        "scarstore_router_file": "scarstore_router.json" if scarstore_info is not None else None,
        "architecture": {
            "hidden_dim": hidden_dim,
            "num_layers": num_layers,
            "num_q_heads": num_q_heads,
            "num_kv_heads": num_kv_heads,
            "head_dim": head_dim,
            "intermediate_size": inter_dim,
            "vocab_size": vocab_size,
            "rms_norm_eps": rms_norm_eps,
            "rope_theta": rope_theta,
            "rope_inv_freq": inv_freq,
            "mos_rank": int(mos_rank),
            "eos_token_ids": eos_ids,
            "user_turn_prefix_ids": [151644, 872, 198],
        },
        "scache_defaults": {
            "window_size": 128,
            "num_sink_tokens": 36,
            "num_slots": 32,
            "delta_blend": 0.05,
        },
        "shards": shards_manifest,
        "total_weights_bytes": total_b,
        "total_weights_mib": round(total_b / (1024.0 * 1024.0), 3),
        "max_shard_bytes": max_shard_b,
        "max_shard_mib": round(max_shard_b / (1024.0 * 1024.0), 3),
        "under_128mib_universal_limit": bool(max_shard_b <= 128 * 1024 * 1024),
        "embed_chunks": vocab_chunks_meta,
        "lm_head_chunks": lm_head_chunks_meta,
        "layers": layers_meta,
        "final_norm": {
            "shard_index": fn_shard_idx,
            "w_u32_off": fn_u32_off,
        },
    }
    (out_dir / "webgpu_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    elapsed = time.perf_counter() - t0
    return WebGPUExportReport(
        model_id=str(model_id_or_path),
        output_dir=str(out_dir.resolve()),
        hidden_dim=hidden_dim,
        num_layers=num_layers,
        num_q_heads=num_q_heads,
        num_kv_heads=num_kv_heads,
        head_dim=head_dim,
        intermediate_size=inter_dim,
        vocab_size=vocab_size,
        mos_rank=int(mos_rank),
        num_shards=len(shards_manifest),
        max_shard_mib=round(max_shard_b / (1024.0 * 1024.0), 3),
        total_weights_mib=round(total_b / (1024.0 * 1024.0), 3),
        under_128mib_universal_limit=bool(max_shard_b <= 128 * 1024 * 1024),
        scarstore_capsules=int(scarstore_info["num_capsules"]) if scarstore_info else 0,
        scarstore_record_bytes=int(scarstore_info["record_bytes"]) if scarstore_info else 0,
        export_seconds=round(elapsed, 3),
    )


def _pack_kernel_params(
    p0: int = 0,
    p1: int = 0,
    p2: int = 0,
    p3: int = 0,
    p4: int = 0,
    p5: int = 0,
    p6: int = 0,
    p7: int = 0,
    f0: float = 0.0,
    f1: float = 0.0,
    f2: float = 0.0,
    f3: float = 0.0,
) -> bytes:
    return struct.pack(
        "<8I8f",
        int(p0),
        int(p1),
        int(p2),
        int(p3),
        int(p4),
        int(p5),
        int(p6),
        int(p7),
        float(f0),
        float(f1),
        float(f2),
        float(f3),
        0.0,
        0.0,
        0.0,
        0.0,
    )


class NativeWebGPUMoSEngine:
    """Executes the exact `mos_scache_kernels.wgsl` compute shaders on physical GPU hardware via `wgpu-py`.

    Used for hardware parity verification (`mos-webgpu verify` & `pytest`) against PyTorch on Metal/Vulkan/DX12,
    sharing the exact binary shard format, `SCache O(1)` layout, and `HeadExpandedScarStore` injection as Chrome.
    """

    def __init__(
        self,
        bundle_dir: Union[str, Path],
        window_size: Optional[int] = None,
        num_slots: Optional[int] = None,
        num_sink_tokens: Optional[int] = None,
        delta_blend: Optional[float] = None,
        capsule_range_fetcher: Optional[Callable[[int, int], bytes]] = None,
    ) -> None:
        import wgpu

        self.wgpu = wgpu
        self.bundle_dir = Path(bundle_dir)
        self.manifest = json.loads((self.bundle_dir / "webgpu_manifest.json").read_text(encoding="utf-8"))
        arch = self.manifest["architecture"]
        sc_def = self.manifest["scache_defaults"]

        self.hidden_dim = int(arch["hidden_dim"])
        self.num_layers = int(arch["num_layers"])
        self.num_q_heads = int(arch["num_q_heads"])
        self.num_kv_heads = int(arch["num_kv_heads"])
        self.head_dim = int(arch["head_dim"])
        self.inter_dim = int(arch["intermediate_size"])
        self.vocab_size = int(arch["vocab_size"])
        self.rms_norm_eps = float(arch["rms_norm_eps"])
        self.mos_rank = int(arch["mos_rank"])
        self.eos_token_ids = set(int(x) for x in arch.get("eos_token_ids", []))
        self.user_turn_prefix_ids = [int(x) for x in arch.get("user_turn_prefix_ids", [151644, 872, 198])]

        self.window_size = int(window_size if window_size is not None else sc_def["window_size"])
        self.num_sink = min(
            int(num_sink_tokens if num_sink_tokens is not None else sc_def["num_sink_tokens"]),
            self.window_size // 2,
        )
        self.slide_len = max(1, self.window_size - self.num_sink)
        self.num_slots = int(num_slots if num_slots is not None else sc_def["num_slots"])
        self.delta_blend = float(delta_blend if delta_blend is not None else sc_def["delta_blend"])

        self.adapter = wgpu.gpu.request_adapter_sync(power_preference="high-performance")
        if self.adapter is None:
            raise RuntimeError("No WebGPU hardware adapter available on this machine.")
        info = self.adapter.info
        self.adapter_name = str(info.get("device") or info.get("description") or "WebGPU Adapter")
        self.backend_type = str(info.get("backend_type") or "Unknown")

        # Request default WebGPU limits (strictly <= 128 MiB per storage binding!)
        self.device = self.adapter.request_device_sync(required_limits={})

        required_entrypoints = (
            "embed_int4_lookup",
            "rmsnorm_f32",
            "fp16_gemv_bias",
            "mos_fused_int4_bscar_gemv",
            "qwen_rope_inplace",
            "scache_o1_update_widrow_hoff",
            "scache_o1_gqa_attention",
            "swiglu_mul_f32",
            "vec_add_inplace_f32",
            "vec_copy_f32",
            "head_expanded_scar_inject",
            "golden_slice_scar_inject",
            "int4_vocab_logits_gemv",
            "logits_top2_reduce_stage1",
            "logits_top2_reduce_stage2",
            "vq4_equilibrate_fwht64",
            "mos_fused_vq4_int4scar_gemv",
            "apply_script_subspace_gate",
            "vec_equilibrate_f16",
            "mos_fused_prot_int4_int4scar_gemv",
        )
        wgsl_path = self.bundle_dir / self.manifest.get("wgsl_shader", "mos_scache_kernels.wgsl")
        if not wgsl_path.exists():
            wgsl_path = WGSL_KERNELS_PATH
        wgsl_code = wgsl_path.read_text(encoding="utf-8")
        if any(f"fn {ep}" not in wgsl_code for ep in required_entrypoints):
            wgsl_code = WGSL_KERNELS_PATH.read_text(encoding="utf-8")
        self.shader_module = self.device.create_shader_module(code=wgsl_code)

        self.pipelines: Dict[str, Any] = {}
        for ep in required_entrypoints:
            self.pipelines[ep] = self.device.create_compute_pipeline(
                layout="auto",
                compute={"module": self.shader_module, "entry_point": ep},
            )

        U = wgpu.BufferUsage
        # Upload static weight shards
        self.shard_buffers: List[Any] = []
        self.total_weight_gpu_bytes = 0
        for s_meta in self.manifest["shards"]:
            raw = (self.bundle_dir / s_meta["filename"]).read_bytes()
            buf = self.device.create_buffer_with_data(data=raw, usage=U.STORAGE)
            self.shard_buffers.append(buf)
            self.total_weight_gpu_bytes += int(buf.size)

        # Allocate strictly O(1) constant SCache GPU buffers (NEVER resized across infinite context!)
        total_kv_heads = self.num_layers * self.num_kv_heads
        self.counts_u32_total = total_kv_heads * 4
        cap_per_head = self.num_sink + self.num_slots + self.slide_len
        vec_u32 = self.head_dim // 2
        kv_u32_words = self.counts_u32_total + total_kv_heads * 2 * cap_per_head * vec_u32

        self.scache_kv_buf = self.device.create_buffer(
            size=kv_u32_words * 4,
            usage=U.STORAGE | U.COPY_DST | U.COPY_SRC,
        )
        self.scache_w_scar_buf = self.device.create_buffer(
            size=total_kv_heads * self.head_dim * self.head_dim * 4,
            usage=U.STORAGE | U.COPY_DST | U.COPY_SRC,
        )
        self.scache_salience_buf = self.device.create_buffer(
            size=max(16, total_kv_heads * max(1, self.num_slots) * 4),
            usage=U.STORAGE | U.COPY_DST | U.COPY_SRC,
        )
        self.scache_kv_snap_buf = self.device.create_buffer(
            size=self.scache_kv_buf.size,
            usage=U.COPY_DST | U.COPY_SRC,
        )
        self.scache_w_scar_snap_buf = self.device.create_buffer(
            size=self.scache_w_scar_buf.size,
            usage=U.COPY_DST | U.COPY_SRC,
        )
        self.scache_sal_snap_buf = self.device.create_buffer(
            size=self.scache_salience_buf.size,
            usage=U.COPY_DST | U.COPY_SRC,
        )
        self.session_pos: int = 0
        self.turn_count: int = 0

        # Scratch single-token activation buffers
        q_dim = self.num_q_heads * self.head_dim
        kv_dim = self.num_kv_heads * self.head_dim
        self.step_state_buf = self.device.create_buffer(size=16, usage=U.STORAGE | U.COPY_DST)
        self.prefill_steps_buf = self.device.create_buffer(
            size=PREFILL_BATCH_TOKENS * 16,
            usage=U.COPY_SRC | U.COPY_DST,
        )
        self.inv_freq_buf = self.device.create_buffer_with_data(
            data=np.asarray(arch["rope_inv_freq"], dtype=np.float32).tobytes(),
            usage=U.STORAGE,
        )
        self.h_cur_buf = self.device.create_buffer(size=self.hidden_dim * 4, usage=U.STORAGE | U.COPY_SRC | U.COPY_DST)
        self.norm_buf = self.device.create_buffer(size=self.hidden_dim * 4, usage=U.STORAGE | U.COPY_SRC)
        self.q_buf = self.device.create_buffer(size=q_dim * 4, usage=U.STORAGE | U.COPY_SRC)
        self.k_buf = self.device.create_buffer(size=kv_dim * 4, usage=U.STORAGE)
        self.v_buf = self.device.create_buffer(size=kv_dim * 4, usage=U.STORAGE)
        self.q_unroped_last_buf = self.device.create_buffer(size=q_dim * 4, usage=U.STORAGE | U.COPY_SRC)
        self.attn_out_buf = self.device.create_buffer(size=q_dim * 4, usage=U.STORAGE)
        self.proj_out_buf = self.device.create_buffer(size=self.hidden_dim * 4, usage=U.STORAGE)
        self.gate_buf = self.device.create_buffer(size=self.inter_dim * 4, usage=U.STORAGE)
        self.up_buf = self.device.create_buffer(size=self.inter_dim * 4, usage=U.STORAGE)
        self.asvd_u_buf = self.device.create_buffer(size=max(256, self.mos_rank) * 4, usage=U.STORAGE)
        max_lin_in = max(self.hidden_dim, q_dim, self.inter_dim)
        self.vq4_x_rot_buf = self.device.create_buffer(size=max_lin_in * 4, usage=U.STORAGE)
        self.vq4_dummy_buf = self.device.create_buffer(size=16, usage=U.STORAGE)
        self.logits_buf = self.device.create_buffer(size=self.vocab_size * 4, usage=U.STORAGE | U.COPY_SRC)
        self.top2_s1_f32_buf = self.device.create_buffer(size=256 * 3 * 4, usage=U.STORAGE)
        self.top2_s1_u32_buf = self.device.create_buffer(size=256 * 4, usage=U.STORAGE)
        self.top2_out_buf = self.device.create_buffer(size=16, usage=U.STORAGE | U.COPY_SRC)

        # Script-Orthogonal Active Subspace Gate (`P_perp_CJK` — 18.55 KB bitmask, default no-op until western query)
        self._cjk_bitmask_ready = False
        n_mask_words = (self.vocab_size + 31) // 32
        self.cjk_bitmask_buf = self.device.create_buffer(size=max(16, n_mask_words * 4), usage=U.STORAGE | U.COPY_DST)
        self.script_gate_uniform = self.device.create_buffer(size=64, usage=U.UNIFORM | U.COPY_DST)
        self._set_script_gate_gpu(suppress_cjk=False)

        # ScarStore calibration + active `+M` capsules buffers
        self.capsule_range_fetcher = capsule_range_fetcher
        self._init_scarstore_buffers()

        # Pre-build all static bind groups across all layers for zero per-token overhead!
        self._prebuild_dispatch_plan()
        self.reset_scache()

    @property
    def scache_gpu_bytes(self) -> int:
        """Exact physical GPU bytes allocated to `SCache O(1)` (`GPUBuffer.size` sum — strictly constant!)."""
        return int(self.scache_kv_buf.size + self.scache_w_scar_buf.size + self.scache_salience_buf.size)

    def _make_uniform(self, raw64: bytes) -> Any:
        return self.device.create_buffer_with_data(data=raw64, usage=self.wgpu.BufferUsage.UNIFORM)

    def _bg(self, ep: str, bindings: Dict[int, Any]) -> Any:
        layout = self.pipelines[ep].get_bind_group_layout(0)
        entries = [
            {"binding": b_idx, "resource": {"buffer": buf, "offset": 0, "size": buf.size}}
            for b_idx, buf in sorted(bindings.items())
        ]
        return self.device.create_bind_group(layout=layout, entries=entries)

    def _init_scarstore_buffers(self) -> None:
        U = self.wgpu.BufferUsage
        q_dim = self.num_q_heads * self.head_dim
        self.router_meta: Optional[Dict[str, Any]] = None
        self.is_golden_slice_v4: bool = False
        self.mid_layer_idx: int = max(0, min(self.num_layers - 2, int(round(2.0 * self.num_layers / 3.0)) - 1))
        self.mu_query_last_np: Optional[np.ndarray] = None
        self.u_lang_mid_np: Optional[np.ndarray] = None
        self.z_anchors_np: Optional[np.ndarray] = None
        self._cached_capsules: Dict[str, Any] = {}
        self._unlearned_capsules: set[str] = set()
        self.http206_bytes_fetched = 0
        self.scar_rank_mid = 12
        self.scar_rank_final = 52
        self.seed_horizon = 44
        self.seed_fade_steps = 16
        self.winner_margin = 0.0002
        self.user_turn_suffix_ids: List[int] = [151645, 198, 151644, 77091, 198]

        router_file = self.manifest.get("scarstore_router_file")
        router_path = (self.bundle_dir / router_file) if router_file else None
        if router_path is not None and router_path.exists():
            self.router_meta = json.loads(router_path.read_text(encoding="utf-8"))
            rbin = (self.bundle_dir / self.router_meta["router_bin_file"]).read_bytes()
            floats = np.frombuffer(rbin, dtype=np.float32)
            lay = self.router_meta["router_bin_layout"]
            n_caps = int(self.router_meta["num_capsules"])
            o_za, n_za = lay["z_anchors"]["offset_floats"], lay["z_anchors"]["length_floats"]
            self.z_anchors_np = (
                floats[o_za : o_za + n_za].reshape(n_caps, self.hidden_dim).copy()
                if n_caps > 0
                else np.zeros((0, self.hidden_dim), dtype=np.float32)
            )
            if self.router_meta.get("routing_architecture") == "golden_slice_v4":
                self.is_golden_slice_v4 = True
                self.mid_layer_idx = int(self.router_meta["mid_layer_idx"])
                self.scar_rank_mid = int(self.router_meta["rank_mid"])
                self.scar_rank_final = int(self.router_meta["rank_final"])
                self.scar_rank = self.scar_rank_mid + self.scar_rank_final
                self.scar_num_proto = 0
                self.scar_beta = 0.0
                self.k_lang = int(self.router_meta["k_lang"])
                self.seed_horizon = int(self.router_meta.get("seed_horizon", 44))
                self.seed_fade_steps = int(self.router_meta.get("seed_fade_steps", 16))
                self.winner_margin = float(self.router_meta.get("winner_margin", 0.0002))
                self.user_turn_suffix_ids = [
                    int(x) for x in self.router_meta.get("user_turn_suffix_ids", [151645, 198, 151644, 77091, 198])
                ]
                o_qm, n_qm = lay["mu_query_mid"]["offset_floats"], lay["mu_query_mid"]["length_floats"]
                o_hm, n_hm = lay["mu_hidden_mid"]["offset_floats"], lay["mu_hidden_mid"]["length_floats"]
                o_hf, n_hf = lay["mu_hidden_final"]["offset_floats"], lay["mu_hidden_final"]["length_floats"]
                o_ul, n_ul = lay["u_lang_mid"]["offset_floats"], lay["u_lang_mid"]["length_floats"]
                self.mu_query_last_np = floats[o_qm : o_qm + n_qm].copy()
                self.u_lang_mid_np = floats[o_ul : o_ul + n_ul].reshape(self.hidden_dim, self.k_lang).copy()
                cal_concat = np.concatenate([floats[o_hm : o_hm + n_hm], floats[o_hf : o_hf + n_hf]]).astype(np.float32)
            else:
                o_ql, n_ql = lay["mu_query_last"]["offset_floats"], lay["mu_query_last"]["length_floats"]
                o_hf, n_hf = lay["mu_hidden_final"]["offset_floats"], lay["mu_hidden_final"]["length_floats"]
                o_qh, n_qh = lay["mu_q_heads"]["offset_floats"], lay["mu_q_heads"]["length_floats"]
                self.mu_query_last_np = floats[o_ql : o_ql + n_ql].copy()
                cal_concat = np.concatenate([floats[o_hf : o_hf + n_hf], floats[o_qh : o_qh + n_qh]]).astype(np.float32)
                self.scar_rank = int(self.router_meta["rank"])
                self.scar_num_proto = int(self.router_meta["num_key_prototypes"])
                self.scar_beta = float(self.router_meta.get("attention_beta", 14.0))
        else:
            cal_concat = np.zeros((self.hidden_dim + q_dim,), dtype=np.float32)
            self.scar_rank = 60
            self.scar_num_proto = 8
            self.scar_beta = 14.0

        self.scar_calib_buf = self.device.create_buffer_with_data(data=cal_concat.tobytes(), usage=U.STORAGE)
        if self.is_golden_slice_v4:
            self.scar_mid_stride = 1 + 2 * (self.scar_rank_mid * self.hidden_dim)
            self.scar_cap_stride = 1 + 2 * (self.scar_rank_final * self.hidden_dim)
            self.active_mid_capsules_buf = self.device.create_buffer(
                size=max(64, 8 * self.scar_mid_stride * 4),
                usage=U.STORAGE | U.COPY_DST,
            )
            self.scar_mid_uniform = self.device.create_buffer(size=64, usage=U.UNIFORM | U.COPY_DST)
        else:
            self.scar_mid_stride = 1
            self.scar_cap_stride = 1 + 2 * (self.scar_rank * self.hidden_dim) + (self.scar_num_proto * q_dim)
            self.active_mid_capsules_buf = self.device.create_buffer(size=64, usage=U.STORAGE | U.COPY_DST)
            self.scar_mid_uniform = self.device.create_buffer(size=64, usage=U.UNIFORM | U.COPY_DST)

        self.active_capsules_buf = self.device.create_buffer(
            size=max(64, 8 * self.scar_cap_stride * 4),
            usage=U.STORAGE | U.COPY_DST,
        )
        self.scar_telemetry_buf = self.device.create_buffer(size=64, usage=U.STORAGE | U.COPY_SRC | U.COPY_DST)
        self.scar_inject_uniform = self.device.create_buffer(size=64, usage=U.UNIFORM | U.COPY_DST)
        self._set_active_capsules_gpu([])

    def _update_horizon_scale_gpu(self, step_idx: int) -> None:
        if not self.is_golden_slice_v4:
            return
        from scar_cache.golden_slice_v4 import compute_horizon_scale

        hw = compute_horizon_scale(step_idx, self.seed_horizon, self.seed_fade_steps)
        m_act = self._current_m_active
        u_mid = _pack_kernel_params(
            p0=self.hidden_dim,
            p1=self.scar_rank_mid,
            p2=m_act,
            p3=0,
            f0=hw,
        )
        u_fin = _pack_kernel_params(
            p0=self.hidden_dim,
            p1=self.scar_rank_final,
            p2=m_act,
            p3=self.hidden_dim,
            f0=hw,
        )
        self.device.queue.write_buffer(self.scar_mid_uniform, 0, u_mid)
        self.device.queue.write_buffer(self.scar_inject_uniform, 0, u_fin)

    def _set_active_capsules_gpu(self, active_list: List[Tuple[str, float, Any]], horizon_scale: float = 1.0) -> None:
        m_act = min(8, len(active_list))
        self._current_m_active = m_act
        self._current_active_cids = [cid for cid, _, _ in active_list[:m_act]]
        self._current_active_gates = {cid: round(float(g), 4) for cid, g, _ in active_list[:m_act]}

        if self.is_golden_slice_v4:
            if m_act > 0:
                w_sum = sum(float(g) for _, g, _ in active_list[:m_act])
                norm_div = w_sum if (m_act > 1 and w_sum > 1.0) else 1.0
                pk_mid = np.zeros((m_act * self.scar_mid_stride,), dtype=np.float32)
                pk_fin = np.zeros((m_act * self.scar_cap_stride,), dtype=np.float32)
                for idx, (_, g_val, cap_dict) in enumerate(active_list[:m_act]):
                    eff_g = float(g_val) / norm_div
                    bm = idx * self.scar_mid_stride
                    bf = idx * self.scar_cap_stride
                    pk_mid[bm] = eff_g
                    pk_mid[bm + 1 : bm + self.scar_mid_stride] = cap_dict["mid"]
                    pk_fin[bf] = eff_g
                    pk_fin[bf + 1 : bf + self.scar_cap_stride] = cap_dict["final"]
                self.device.queue.write_buffer(self.active_mid_capsules_buf, 0, pk_mid.tobytes())
                self.device.queue.write_buffer(self.active_capsules_buf, 0, pk_fin.tobytes())

            u_mid = _pack_kernel_params(
                p0=self.hidden_dim,
                p1=self.scar_rank_mid,
                p2=m_act,
                p3=0,
                f0=float(horizon_scale),
            )
            u_fin = _pack_kernel_params(
                p0=self.hidden_dim,
                p1=self.scar_rank_final,
                p2=m_act,
                p3=self.hidden_dim,
                f0=float(horizon_scale),
            )
            self.device.queue.write_buffer(self.scar_mid_uniform, 0, u_mid)
            self.device.queue.write_buffer(self.scar_inject_uniform, 0, u_fin)
            return

        if m_act > 0:
            packed = np.zeros((m_act * self.scar_cap_stride,), dtype=np.float32)
            for idx, (_, g_val, cap_arr) in enumerate(active_list[:m_act]):
                base = idx * self.scar_cap_stride
                packed[base] = float(g_val)
                packed[base + 1 : base + self.scar_cap_stride] = cap_arr
            self.device.queue.write_buffer(self.active_capsules_buf, 0, packed.tobytes())

        u_bytes = _pack_kernel_params(
            p0=self.hidden_dim,
            p1=self.num_q_heads,
            p2=self.head_dim,
            p3=self.scar_rank,
            p4=m_act,
            p5=self.scar_num_proto,
            f0=self.scar_beta,
        )
        self.device.queue.write_buffer(self.scar_inject_uniform, 0, u_bytes)

    def _unpack_capsule_int4_bytes_np(self, raw: bytes) -> Any:
        """Pure NumPy `Block-64 INT4` capsule unpacker matching `scarstore_http206_browser.js` bit-for-bit."""
        d = self.hidden_dim
        off = 0

        def _deq(n_blk: int) -> np.ndarray:
            nonlocal off
            pk = np.frombuffer(raw, dtype=np.uint8, count=n_blk * 32, offset=off).reshape(n_blk, 32)
            off += n_blk * 32
            sc = np.frombuffer(raw, dtype=np.float16, count=n_blk, offset=off).astype(np.float32)
            off += n_blk * 2
            out = np.empty((n_blk, 64), dtype=np.float32)
            out[:, 0::2] = (pk & 0x0F).astype(np.float32) - 8.0
            out[:, 1::2] = ((pk >> 4) & 0x0F).astype(np.float32) - 8.0
            out *= sc[:, None]
            return out.reshape(-1)

        if self.is_golden_slice_v4:
            n_mid = (d * self.scar_rank_mid) // 64
            n_fin = (d * self.scar_rank_final) // 64
            b_mid = _deq(n_mid)
            a_mid = _deq(n_mid)
            b_fin = _deq(n_fin)
            a_fin = _deq(n_fin)
            return {
                "mid": np.concatenate([a_mid, b_mid]).astype(np.float32),
                "final": np.concatenate([a_fin, b_fin]).astype(np.float32),
            }

        r = self.scar_rank
        p_cnt = self.scar_num_proto
        q_dim = self.num_q_heads * self.head_dim
        n_ab = (d * r) // 64
        n_k = (p_cnt * q_dim) // 64
        b_flat = _deq(n_ab)
        a_flat = _deq(n_ab)
        k_flat = _deq(n_k).reshape(p_cnt, self.num_q_heads, self.head_dim)
        norms = np.maximum(np.linalg.norm(k_flat, axis=-1, keepdims=True), 1e-8)
        k_norm_flat = (k_flat / norms).astype(np.float32).reshape(-1)
        return np.concatenate([a_flat, b_flat, k_norm_flat]).astype(np.float32)

    def _fetch_and_unpack_capsule(self, cap_entry: Dict[str, Any]) -> Any:
        cid = str(cap_entry["capsule_id"])
        if cid in self._cached_capsules:
            return self._cached_capsules[cid]
        off = int(cap_entry["byte_offset"])
        rec_b = int(cap_entry["record_bytes"])
        if self.capsule_range_fetcher is not None:
            raw = self.capsule_range_fetcher(off, rec_b)
            self.http206_bytes_fetched += len(raw)
        else:
            local_name = self.router_meta.get("local_http206_store_url") if self.router_meta else None
            if not local_name or not (self.bundle_dir / local_name).exists():
                raise FileNotFoundError(f"Missing local ScarStore file for capsule {cid} and no HTTP 206 fetcher set.")
            with open(self.bundle_dir / local_name, "rb") as f:
                f.seek(off)
                raw = f.read(rec_b)
            self.http206_bytes_fetched += len(raw)
        arr = self._unpack_capsule_int4_bytes_np(raw)
        self._cached_capsules[cid] = arr
        return arr

    def unlearn_capsule(self, capsule_id: str) -> int:
        """Zeroes browser/host cached weights (`0x00` cryptographic wipe) and disables routing cone."""
        wiped = 0
        arr = self._cached_capsules.pop(capsule_id, None)
        if arr is not None:
            if isinstance(arr, dict):
                for sub_a in arr.values():
                    sub_a.fill(0.0)
                    wiped += int(sub_a.nbytes)
            else:
                arr.fill(0.0)
                wiped = int(arr.nbytes)
        self._unlearned_capsules.add(capsule_id)
        self._set_active_capsules_gpu([])
        return wiped

    def route_prompt_states(self, x_in_2d: np.ndarray) -> List[Tuple[str, float, Any]]:
        """Exact `Span-Max` spherical cone router (`P_perp_lang` Golden-Slice v4 or Head-Expanded v3)."""
        if self.router_meta is None or self.mu_query_last_np is None or self.z_anchors_np is None:
            return []
        caps = self.router_meta.get("capsules", [])
        if not caps or x_in_2d.shape[0] == 0:
            return []

        lu = int(x_in_2d.shape[0])
        mu = self.mu_query_last_np
        q_g = x_in_2d.mean(axis=0) - mu
        q_g = q_g / max(float(np.linalg.norm(q_g)), 1e-8)
        probes = [q_g]

        win = int(self.router_meta.get("span_window", 10))
        stride = int(self.router_meta.get("span_stride", 3))
        if lu >= win + 4:
            w_eff = min(win, lu)
            starts = list(range(0, max(1, lu - w_eff + 1), max(1, stride)))
            if (lu - w_eff) not in starts:
                starts.append(lu - w_eff)
            if lu > w_eff + 5 and (lu - 5 - w_eff) > 0 and (lu - 5 - w_eff) not in starts:
                starts.append(lu - 5 - w_eff)
            starts.sort()
            for s in starts:
                e = min(lu, s + w_eff)
                if e - s < 4:
                    continue
                v = x_in_2d[s:e].mean(axis=0) - mu
                probes.append(v / max(float(np.linalg.norm(v)), 1e-8))

        probes_mat = np.stack(probes, axis=0)  # [N_p, d]
        if self.is_golden_slice_v4 and self.u_lang_mid_np is not None:
            probes_mat = probes_mat - (probes_mat @ self.u_lang_mid_np) @ self.u_lang_mid_np.T
            norms = np.maximum(np.linalg.norm(probes_mat, axis=-1, keepdims=True), 1e-8)
            probes_mat = (probes_mat / norms).astype(np.float32)

        cos_vec = (probes_mat @ self.z_anchors_np.T).max(axis=0)  # [N_caps]

        g_vals: List[float] = []
        id_to_idx: Dict[str, int] = {}
        for i, c in enumerate(caps):
            cid = str(c["capsule_id"])
            id_to_idx[cid] = i
            if cid in self._unlearned_capsules:
                g_vals.append(0.0)
                continue
            tau = float(c["tau"])
            ramp = max(float(c["ramp"]), 1e-6)
            g = min(1.0, max(0.0, (float(cos_vec[i]) - tau) / ramp))
            g_vals.append(g)

        if max(g_vals, default=0.0) <= 0.0:
            return []

        pre_gates = list(g_vals)
        active_bridges: List[int] = []
        for i, c in enumerate(caps):
            parents = c.get("parent_capsules") or []
            if not parents:
                continue
            if any(p not in id_to_idx or pre_gates[id_to_idx[p]] <= 0.0 for p in parents):
                g_vals[i] = 0.0
                continue
            p_min = min(pre_gates[id_to_idx[p]] for p in parents)
            eff_bg = pre_gates[i] * min(1.0, p_min / (0.30 if self.is_golden_slice_v4 else 0.50))
            g_vals[i] = eff_bg
            if eff_bg > 0.0:
                active_bridges.append(i)

        if self.is_golden_slice_v4 and self.winner_margin > 0.0:
            prim_indices = [i for i, c in enumerate(caps) if g_vals[i] > 0.0 and not (c.get("parent_capsules") or [])]
            if len(prim_indices) > 1:
                best_p_cos = max(float(cos_vec[i]) for i in prim_indices)
                for i in prim_indices:
                    if (best_p_cos - float(cos_vec[i])) > self.winner_margin:
                        g_vals[i] = 0.0

        for b_idx in active_bridges:
            atten = max(0.0, 1.0 - g_vals[b_idx])
            for p in caps[b_idx].get("parent_capsules") or []:
                g_vals[id_to_idx[p]] = pre_gates[id_to_idx[p]] * atten

        if self.is_golden_slice_v4 and not active_bridges:
            active_idxs = [i for i in range(len(caps)) if g_vals[i] > 1e-6]
            if len(active_idxs) == 1:
                g_vals[active_idxs[0]] = 1.0

        active_out: List[Tuple[str, float, Any]] = []
        for i, c in enumerate(caps):
            if g_vals[i] > 1e-6:
                arr = self._fetch_and_unpack_capsule(c)
                active_out.append((str(c["capsule_id"]), float(g_vals[i]), arr))
        return active_out

    def _set_script_gate_gpu(self, suppress_cjk: bool, penalty: float = 64.0) -> None:
        u_bytes = _pack_kernel_params(
            p0=self.vocab_size,
            p1=1 if suppress_cjk else 0,
            f0=float(penalty),
        )
        self.device.queue.write_buffer(self.script_gate_uniform, 0, u_bytes)

    def _ensure_cjk_bitmask_gpu(self, tokenizer: Any) -> None:
        if self._cjk_bitmask_ready:
            return
        from scar_cache.vq4_scar_mos import build_cjk_vocab_bitmask_u32

        mask_u32 = build_cjk_vocab_bitmask_u32(tokenizer, self.vocab_size)
        self.device.queue.write_buffer(self.cjk_bitmask_buf, 0, mask_u32.tobytes())
        self._cjk_bitmask_ready = True

    def _make_linear_ops(self, shard_buf: Any, spec: Dict[str, Any], x_buf: Any, y_buf: Any) -> List[Tuple[str, Any, int]]:
        ops: List[Tuple[str, Any, int]] = []
        out_dim = int(spec["out_dim"])
        in_dim = int(spec["in_dim"])
        wgs = (out_dim + 7) // 8
        if spec["mode"] == "fp16":
            u = self._make_uniform(
                _pack_kernel_params(
                    p0=out_dim,
                    p1=in_dim,
                    p2=spec["w_u32_off"],
                    p3=spec["bias_u32_off"],
                    p4=spec["has_bias"],
                )
            )
            bg = self._bg("fp16_gemv_bias", {0: u, 1: shard_buf, 3: x_buf, 6: y_buf})
            ops.append(("fp16_gemv_bias", bg, wgs))
        elif spec["mode"] == "vq4_scar":
            rank = int(spec["rank"])
            u_eq = self._make_uniform(_pack_kernel_params(p0=in_dim, p1=spec["d_eq_u32_off"]))
            bg_eq = self._bg(
                "vq4_equilibrate_fwht64",
                {0: u_eq, 1: shard_buf, 3: x_buf, 6: self.vq4_x_rot_buf},
            )
            ops.append(("vq4_equilibrate_fwht64", bg_eq, in_dim >> 6))

            if rank > 0:
                u_a = self._make_uniform(
                    _pack_kernel_params(
                        p0=rank,
                        p1=in_dim,
                        p2=0,
                        p3=spec["ascar_packed_u32_off"],
                        p4=spec["ascar_scales_u32_off"],
                    )
                )
                bg_a = self._bg(
                    "mos_fused_int4_bscar_gemv",
                    {0: u_a, 1: shard_buf, 3: x_buf, 4: self.vq4_dummy_buf, 6: self.asvd_u_buf},
                )
                ops.append(("mos_fused_int4_bscar_gemv", bg_a, (rank + 7) >> 3))

            p7_bias = ((1 << 31) | int(spec["bias_u32_off"])) if int(spec["has_bias"]) else 0
            u_vq = self._make_uniform(
                _pack_kernel_params(
                    p0=out_dim,
                    p1=in_dim,
                    p2=rank,
                    p3=spec["vq_codes_u32_off"],
                    p4=spec["vq_scales_u32_off"],
                    p5=spec["lut256_u32_off"],
                    p6=spec["bscar_u32_off"],
                    p7=p7_bias,
                )
            )
            bg_vq = self._bg(
                "mos_fused_vq4_int4scar_gemv",
                {0: u_vq, 1: shard_buf, 3: self.vq4_x_rot_buf, 4: self.asvd_u_buf, 6: y_buf},
            )
            ops.append(("mos_fused_vq4_int4scar_gemv", bg_vq, wgs))
        elif spec["mode"] == "prot_int4_scar":
            rank = int(spec["rank"])
            has_deq = int(spec.get("has_d_eq", 0)) != 0
            x_base_buf = self.vq4_x_rot_buf if has_deq else x_buf
            if has_deq:
                u_eq = self._make_uniform(_pack_kernel_params(p0=in_dim, p1=spec["d_eq_u32_off"]))
                bg_eq = self._bg(
                    "vec_equilibrate_f16",
                    {0: u_eq, 1: shard_buf, 3: x_buf, 6: self.vq4_x_rot_buf},
                )
                ops.append(("vec_equilibrate_f16", bg_eq, (in_dim + 255) >> 8))

            if rank > 0:
                u_a = self._make_uniform(
                    _pack_kernel_params(
                        p0=rank,
                        p1=in_dim,
                        p2=0,
                        p3=spec["ascar_packed_u32_off"],
                        p4=spec["ascar_scales_u32_off"],
                    )
                )
                bg_a = self._bg(
                    "mos_fused_int4_bscar_gemv",
                    {0: u_a, 1: shard_buf, 3: x_buf, 4: self.vq4_dummy_buf, 6: self.asvd_u_buf},
                )
                ops.append(("mos_fused_int4_bscar_gemv", bg_a, (rank + 7) >> 3))

            u_prot = self._make_uniform(
                _pack_kernel_params(
                    p0=out_dim,
                    p1=in_dim,
                    p2=rank,
                    p3=spec["packed_u32_off"],
                    p4=spec["scales_u32_off"],
                    p5=spec["bscar_u32_off"],
                    p6=spec["bias_u32_off"],
                    p7=spec["has_bias"],
                )
            )
            bg_prot = self._bg(
                "mos_fused_prot_int4_int4scar_gemv",
                {0: u_prot, 1: shard_buf, 3: x_base_buf, 4: self.asvd_u_buf, 6: y_buf},
            )
            ops.append(("mos_fused_prot_int4_int4scar_gemv", bg_prot, wgs))
        else:
            rank = int(spec["rank"])
            u_down = self._make_uniform(_pack_kernel_params(p0=rank, p1=in_dim, p2=spec["ascar_u32_off"], p3=0, p4=0))
            bg_down = self._bg("fp16_gemv_bias", {0: u_down, 1: shard_buf, 3: x_buf, 6: self.asvd_u_buf})
            ops.append(("fp16_gemv_bias", bg_down, (rank + 7) // 8))

            u_up = self._make_uniform(
                _pack_kernel_params(
                    p0=out_dim,
                    p1=in_dim,
                    p2=rank,
                    p3=spec["packed_u32_off"],
                    p4=spec["scales_u32_off"],
                    p5=spec["bscar_u32_off"],
                    p6=spec["bias_u32_off"],
                    p7=spec["has_bias"],
                )
            )
            bg_up = self._bg(
                "mos_fused_int4_bscar_gemv",
                {0: u_up, 1: shard_buf, 3: x_buf, 4: self.asvd_u_buf, 6: y_buf},
            )
            ops.append(("mos_fused_int4_bscar_gemv", bg_up, wgs))
        return ops

    def _prebuild_dispatch_plan(self) -> None:
        self.embed_ops: List[Tuple[str, Any, int]] = []
        for ch in self.manifest["embed_chunks"]:
            sb = self.shard_buffers[int(ch["shard_index"])]
            u = self._make_uniform(
                _pack_kernel_params(
                    p0=self.hidden_dim,
                    p1=ch["packed_u32_off"],
                    p2=ch["scales_u32_off"],
                    p3=ch["vocab_start"],
                    p4=ch["vocab_rows"],
                )
            )
            bg = self._bg("embed_int4_lookup", {0: u, 1: sb, 2: self.step_state_buf, 6: self.h_cur_buf})
            self.embed_ops.append(("embed_int4_lookup", bg, (self.hidden_dim + 255) // 256))

        q_dim = self.num_q_heads * self.head_dim
        total_rope_pairs = (self.num_q_heads + self.num_kv_heads) * (self.head_dim // 2)
        u_rope = self._make_uniform(_pack_kernel_params(p0=self.num_q_heads, p1=self.num_kv_heads, p2=self.head_dim))
        bg_rope = self._bg(
            "qwen_rope_inplace",
            {0: u_rope, 2: self.step_state_buf, 3: self.inv_freq_buf, 6: self.q_buf, 7: self.k_buf},
        )

        u_add_h = self._make_uniform(_pack_kernel_params(p0=self.hidden_dim))
        bg_add_h = self._bg("vec_add_inplace_f32", {0: u_add_h, 3: self.proj_out_buf, 6: self.h_cur_buf})

        u_swiglu = self._make_uniform(_pack_kernel_params(p0=self.inter_dim))
        bg_swiglu = self._bg("swiglu_mul_f32", {0: u_swiglu, 3: self.up_buf, 6: self.gate_buf})

        u_copy_q = self._make_uniform(_pack_kernel_params(p0=q_dim))
        bg_copy_q = self._bg("vec_copy_f32", {0: u_copy_q, 3: self.q_buf, 6: self.q_unroped_last_buf})

        attn_scale = 1.0 / math.sqrt(float(self.head_dim))

        self.layer_ops: List[List[Tuple[str, Any, int]]] = []
        for l_idx, l_meta in enumerate(self.manifest["layers"]):
            ops: List[Tuple[str, Any, int]] = []
            sb = self.shard_buffers[int(l_meta["shard_index"])]
            projs = l_meta["projections"]

            # 1. Input RMSNorm
            u_ln1 = self._make_uniform(
                _pack_kernel_params(p0=self.hidden_dim, p1=l_meta["input_layernorm_u32_off"], f0=self.rms_norm_eps)
            )
            ops.append(("rmsnorm_f32", self._bg("rmsnorm_f32", {0: u_ln1, 1: sb, 3: self.h_cur_buf, 6: self.norm_buf}), 1))

            # 2. Q, K, V projections
            ops.extend(self._make_linear_ops(sb, projs["self_attn.q_proj"], self.norm_buf, self.q_buf))
            ops.extend(self._make_linear_ops(sb, projs["self_attn.k_proj"], self.norm_buf, self.k_buf))
            ops.extend(self._make_linear_ops(sb, projs["self_attn.v_proj"], self.norm_buf, self.v_buf))

            # Capture un-rotated Q on last layer `L-1` for `HeadExpandedScarStore` multi-head routing
            if l_idx == self.num_layers - 1:
                ops.append(("vec_copy_f32", bg_copy_q, (q_dim + 255) // 256))

            # 3. Split-Half RoPE on Q & K
            ops.append(("qwen_rope_inplace", bg_rope, (total_rope_pairs + 63) // 64))

            # 4. SCache O(1) Widrow-Hoff Delta + Surprise-Slot Update
            u_sc_upd = self._make_uniform(
                _pack_kernel_params(
                    p0=l_idx,
                    p1=self.num_kv_heads,
                    p2=self.head_dim,
                    p3=self.num_sink,
                    p4=self.num_slots,
                    p5=self.slide_len,
                    p6=self.counts_u32_total,
                )
            )
            bg_sc_upd = self._bg(
                "scache_o1_update_widrow_hoff",
                {
                    0: u_sc_upd,
                    2: self.step_state_buf,
                    3: self.k_buf,
                    4: self.v_buf,
                    6: self.scache_w_scar_buf,
                    7: self.scache_salience_buf,
                    8: self.scache_kv_buf,
                },
            )
            ops.append(("scache_o1_update_widrow_hoff", bg_sc_upd, self.num_kv_heads))

            # 5. SCache O(1) Bounded-Horizon GQA Attention
            u_sc_att = self._make_uniform(
                _pack_kernel_params(
                    p0=l_idx,
                    p1=self.num_q_heads,
                    p2=self.num_kv_heads,
                    p3=self.head_dim,
                    p4=self.num_sink,
                    p5=self.num_slots,
                    p6=self.slide_len,
                    p7=self.counts_u32_total,
                    f0=attn_scale,
                    f1=self.delta_blend,
                )
            )
            bg_sc_att = self._bg(
                "scache_o1_gqa_attention",
                {
                    0: u_sc_att,
                    1: self.scache_kv_buf,
                    3: self.q_buf,
                    4: self.scache_w_scar_buf,
                    6: self.attn_out_buf,
                },
            )
            ops.append(("scache_o1_gqa_attention", bg_sc_att, self.num_q_heads))

            # 6. Output projection + Residual Add
            ops.extend(self._make_linear_ops(sb, projs["self_attn.o_proj"], self.attn_out_buf, self.proj_out_buf))
            ops.append(("vec_add_inplace_f32", bg_add_h, (self.hidden_dim + 255) // 256))

            # 7. Post-Attention RMSNorm + SwiGLU MoS/FP16 MLP + Residual Add
            u_ln2 = self._make_uniform(
                _pack_kernel_params(p0=self.hidden_dim, p1=l_meta["post_attention_layernorm_u32_off"], f0=self.rms_norm_eps)
            )
            ops.append(("rmsnorm_f32", self._bg("rmsnorm_f32", {0: u_ln2, 1: sb, 3: self.h_cur_buf, 6: self.norm_buf}), 1))
            ops.extend(self._make_linear_ops(sb, projs["mlp.gate_proj"], self.norm_buf, self.gate_buf))
            ops.extend(self._make_linear_ops(sb, projs["mlp.up_proj"], self.norm_buf, self.up_buf))
            ops.append(("swiglu_mul_f32", bg_swiglu, (self.inter_dim + 255) // 256))
            ops.extend(self._make_linear_ops(sb, projs["mlp.down_proj"], self.gate_buf, self.proj_out_buf))
            ops.append(("vec_add_inplace_f32", bg_add_h, (self.hidden_dim + 255) // 256))

            self.layer_ops.append(ops)

        # Final RMSNorm + HeadExpandedScarStore Inject + Chunked INT4 Vocab Logits + Top-2 Reduction
        fn_meta = self.manifest["final_norm"]
        fn_sb = self.shard_buffers[int(fn_meta["shard_index"])]
        u_fn = self._make_uniform(_pack_kernel_params(p0=self.hidden_dim, p1=fn_meta["w_u32_off"], f0=self.rms_norm_eps))
        self.final_norm_op = (
            "rmsnorm_f32",
            self._bg("rmsnorm_f32", {0: u_fn, 1: fn_sb, 3: self.h_cur_buf, 6: self.norm_buf}),
            1,
        )

        if self.is_golden_slice_v4:
            self.scar_mid_inject_op = (
                "golden_slice_scar_inject",
                self._bg(
                    "golden_slice_scar_inject",
                    {
                        0: self.scar_mid_uniform,
                        3: self.scar_calib_buf,
                        5: self.active_mid_capsules_buf,
                        6: self.h_cur_buf,
                        7: self.scar_telemetry_buf,
                    },
                ),
                1,
            )
            self.scar_inject_op = (
                "golden_slice_scar_inject",
                self._bg(
                    "golden_slice_scar_inject",
                    {
                        0: self.scar_inject_uniform,
                        3: self.scar_calib_buf,
                        5: self.active_capsules_buf,
                        6: self.norm_buf,
                        7: self.scar_telemetry_buf,
                    },
                ),
                1,
            )
        else:
            self.scar_mid_inject_op = None
            self.scar_inject_op = (
                "head_expanded_scar_inject",
                self._bg(
                    "head_expanded_scar_inject",
                    {
                        0: self.scar_inject_uniform,
                        3: self.scar_calib_buf,
                        4: self.q_unroped_last_buf,
                        5: self.active_capsules_buf,
                        6: self.norm_buf,
                        7: self.scar_telemetry_buf,
                    },
                ),
                1,
            )

        self.lm_head_ops: List[Tuple[str, Any, int]] = []
        for ch in self.manifest["lm_head_chunks"]:
            sb = self.shard_buffers[int(ch["shard_index"])]
            v_rows = int(ch["vocab_rows"])
            u = self._make_uniform(
                _pack_kernel_params(
                    p0=v_rows,
                    p1=self.hidden_dim,
                    p2=ch["packed_u32_off"],
                    p3=ch["scales_u32_off"],
                    p4=ch["vocab_start"],
                )
            )
            bg = self._bg("int4_vocab_logits_gemv", {0: u, 1: sb, 3: self.norm_buf, 6: self.logits_buf})
            self.lm_head_ops.append(("int4_vocab_logits_gemv", bg, (v_rows + 7) // 8))

        bg_script = self._bg(
            "apply_script_subspace_gate",
            {0: self.script_gate_uniform, 1: self.cjk_bitmask_buf, 6: self.logits_buf},
        )
        u_r1 = self._make_uniform(_pack_kernel_params(p0=self.vocab_size))
        bg_r1 = self._bg(
            "logits_top2_reduce_stage1",
            {0: u_r1, 3: self.logits_buf, 6: self.top2_s1_f32_buf, 8: self.top2_s1_u32_buf},
        )
        bg_r2 = self._bg(
            "logits_top2_reduce_stage2",
            {1: self.top2_s1_u32_buf, 3: self.top2_s1_f32_buf, 8: self.top2_out_buf},
        )
        self.reduce_ops = [
            ("apply_script_subspace_gate", bg_script, (self.vocab_size + 255) >> 8),
            ("logits_top2_reduce_stage1", bg_r1, 256),
            ("logits_top2_reduce_stage2", bg_r2, 1),
        ]

    def reset_scache(self) -> None:
        """Clears `SCache O(1)` fast-weights, ring window, and salience in-place (`0 B` reallocation)."""
        self.device.queue.write_buffer(self.scache_kv_buf, 0, bytes(self.scache_kv_buf.size))
        self.device.queue.write_buffer(self.scache_w_scar_buf, 0, bytes(self.scache_w_scar_buf.size))
        self.device.queue.write_buffer(self.scache_salience_buf, 0, bytes(self.scache_salience_buf.size))
        self._set_active_capsules_gpu([])
        self._set_script_gate_gpu(suppress_cjk=False)
        self.http206_bytes_fetched = 0
        self.session_pos = 0
        self.turn_count = 0

    def _record_ops(self, cpass: Any, ops: Sequence[Tuple[str, Any, int]]) -> None:
        for ep, bg, wgs in ops:
            cpass.set_pipeline(self.pipelines[ep])
            cpass.set_bind_group(0, bg)
            cpass.dispatch_workgroups(wgs, 1, 1)

    def _submit_prefill_sequence(
        self,
        token_ids: Sequence[int],
        base_pos: int,
        q_start: int,
        prefill_xin_buf: Optional[Any] = None,
        q_end: Optional[int] = None,
        run_full_on_last: bool = False,
    ) -> None:
        lp = len(token_ids)
        if lp == 0:
            return
        eff_q_end = lp if q_end is None else min(lp, max(q_start + 1, int(q_end)))
        split_idx = self.mid_layer_idx if self.is_golden_slice_v4 else (self.num_layers - 2)

        for batch_start in range(0, lp, PREFILL_BATCH_TOKENS):
            batch_end = min(lp, batch_start + PREFILL_BATCH_TOKENS)
            batch_len = batch_end - batch_start
            steps_arr = np.zeros((batch_len, 4), dtype=np.uint32)
            for i in range(batch_len):
                rel_pos = batch_start + i
                steps_arr[i, 0] = int(token_ids[rel_pos])
                steps_arr[i, 1] = int(base_pos + rel_pos)
            self.device.queue.write_buffer(self.prefill_steps_buf, 0, steps_arr.tobytes())

            enc = self.device.create_command_encoder()
            for i in range(batch_len):
                t_idx = batch_start + i
                enc.copy_buffer_to_buffer(self.prefill_steps_buf, i * 16, self.step_state_buf, 0, 16)
                if t_idx < lp - 1 or run_full_on_last:
                    if prefill_xin_buf is not None and q_start <= t_idx < eff_q_end:
                        cpass_pre = enc.begin_compute_pass()
                        self._record_ops(cpass_pre, self.embed_ops)
                        for l_i in range(split_idx + 1):
                            self._record_ops(cpass_pre, self.layer_ops[l_i])
                        cpass_pre.end()
                        u_slot = t_idx - q_start
                        enc.copy_buffer_to_buffer(
                            self.h_cur_buf, 0, prefill_xin_buf, u_slot * self.hidden_dim * 4, self.hidden_dim * 4
                        )
                        cpass_last = enc.begin_compute_pass()
                        for l_i in range(split_idx + 1, self.num_layers):
                            self._record_ops(cpass_last, self.layer_ops[l_i])
                        cpass_last.end()
                    else:
                        cpass = enc.begin_compute_pass()
                        self._record_ops(cpass, self.embed_ops)
                        for l_ops in self.layer_ops:
                            self._record_ops(cpass, l_ops)
                        cpass.end()
                else:
                    cpass_pre = enc.begin_compute_pass()
                    self._record_ops(cpass_pre, self.embed_ops)
                    for l_i in range(split_idx + 1):
                        self._record_ops(cpass_pre, self.layer_ops[l_i])
                    cpass_pre.end()
                    if prefill_xin_buf is not None and q_start <= t_idx < eff_q_end:
                        u_slot = t_idx - q_start
                        enc.copy_buffer_to_buffer(
                            self.h_cur_buf, 0, prefill_xin_buf, u_slot * self.hidden_dim * 4, self.hidden_dim * 4
                        )
            self.device.queue.submit([enc.finish()])
            _ = self.device.queue.read_buffer(self.top2_out_buf)

    def _flush_closing_tokens_to_scache(self, closing_ids: Sequence[int], start_pos: int) -> int:
        if not closing_ids:
            return start_pos
        n = len(closing_ids)
        for batch_start in range(0, n, PREFILL_BATCH_TOKENS):
            batch_end = min(n, batch_start + PREFILL_BATCH_TOKENS)
            batch_len = batch_end - batch_start
            steps_arr = np.zeros((batch_len, 4), dtype=np.uint32)
            for i in range(batch_len):
                steps_arr[i, 0] = int(closing_ids[batch_start + i])
                steps_arr[i, 1] = int(start_pos + batch_start + i)
            self.device.queue.write_buffer(self.prefill_steps_buf, 0, steps_arr.tobytes())
            enc = self.device.create_command_encoder()
            for i in range(batch_len):
                enc.copy_buffer_to_buffer(self.prefill_steps_buf, i * 16, self.step_state_buf, 0, 16)
                cpass = enc.begin_compute_pass()
                self._record_ops(cpass, self.embed_ops)
                for l_ops in self.layer_ops:
                    self._record_ops(cpass, l_ops)
                cpass.end()
            self.device.queue.submit([enc.finish()])
            _ = self.device.queue.read_buffer(self.top2_out_buf)
        return start_pos + n

    def forward_token(
        self,
        token_id: int,
        pos_t: int,
        return_full_logits: bool = False,
    ) -> Tuple[int, float, float, Optional[np.ndarray]]:
        """Runs a single token through all `L` WGSL layers + `SCache O(1)` + `lm_head` on GPU."""
        state_bytes = struct.pack("<4I", int(token_id), int(pos_t), int(self._current_m_active), 0)
        self.device.queue.write_buffer(self.step_state_buf, 0, state_bytes)

        enc = self.device.create_command_encoder()
        cpass = enc.begin_compute_pass()
        self._record_ops(cpass, self.embed_ops)
        if self.is_golden_slice_v4 and self.scar_mid_inject_op is not None:
            for l_i in range(self.mid_layer_idx + 1):
                self._record_ops(cpass, self.layer_ops[l_i])
            self._record_ops(cpass, [self.scar_mid_inject_op])
            for l_i in range(self.mid_layer_idx + 1, self.num_layers):
                self._record_ops(cpass, self.layer_ops[l_i])
        else:
            for l_ops in self.layer_ops:
                self._record_ops(cpass, l_ops)
        self._record_ops(cpass, [self.final_norm_op, self.scar_inject_op])
        self._record_ops(cpass, self.lm_head_ops)
        self._record_ops(cpass, self.reduce_ops)
        cpass.end()
        self.device.queue.submit([enc.finish()])

        raw16 = self.device.queue.read_buffer(self.top2_out_buf)
        top1_id, v1_u32, v2_u32, sexp_u32 = struct.unpack("<4I", raw16)
        v1 = struct.unpack("<f", struct.pack("<I", v1_u32))[0]
        v2 = struct.unpack("<f", struct.pack("<I", v2_u32))[0]
        sexp = max(struct.unpack("<f", struct.pack("<I", sexp_u32))[0], 1e-12)
        p1 = 1.0 / sexp
        p2 = math.exp(max(-80.0, v2 - v1)) / sexp
        full_lg = None
        if return_full_logits:
            full_lg = np.frombuffer(self.device.queue.read_buffer(self.logits_buf), dtype=np.float32).copy()
        return int(top1_id), float(p1), float(p1 - p2), full_lg

    def generate(
        self,
        user_query: str,
        max_new_tokens: int = 48,
        enable_scarstore: bool = True,
        system_prompt: Optional[str] = None,
        reset_cache: bool = True,
        enable_epistemic_guard: bool = False,
    ) -> WebGPUGenerationResult:
        """End-to-end batched GPU prefill + `Span-Max` `HTTP 206` routing + `SCache O(1)` WGSL generation."""
        from transformers import AutoTokenizer

        from scar_cache.cli_scar_store import select_chat_system_prompt
        from scar_cache.golden_slice_v4 import UNIVERSAL_CHAT_SYSTEM_PROMPT, extract_user_content_bounds
        from scar_cache.scar_grafting import find_subsequence_last_end
        from scar_cache.vq4_scar_mos import has_cjk_script

        if reset_cache:
            self.reset_scache()

        tok = AutoTokenizer.from_pretrained(self.bundle_dir, local_files_only=True)
        self._ensure_cjk_bitmask_gpu(tok)
        self._set_script_gate_gpu(suppress_cjk=(not has_cjk_script(user_query)))
        if system_prompt is not None:
            sys_txt = system_prompt
        elif self.router_meta is not None and self.router_meta.get("system_prompt"):
            sys_txt = str(self.router_meta["system_prompt"])
        elif self.is_golden_slice_v4:
            sys_txt = UNIVERSAL_CHAT_SYSTEM_PROMPT
        else:
            sys_txt = select_chat_system_prompt(user_query)
        messages = [
            {"role": "system", "content": sys_txt},
            {"role": "user", "content": user_query},
        ]
        raw_enc: Any = tok.apply_chat_template(messages, tokenize=True, add_generation_prompt=True)
        clean_probe_ids: List[int] = list(raw_enc["input_ids"] if hasattr(raw_enc, "keys") else raw_enc)
        lp_probe = len(clean_probe_ids)
        if self.is_golden_slice_v4:
            q_start_probe, q_end_probe = extract_user_content_bounds(
                clean_probe_ids, self.user_turn_prefix_ids, self.user_turn_suffix_ids
            )
            lu_probe = max(1, q_end_probe - q_start_probe)
        else:
            q_start_probe = min(find_subsequence_last_end(clean_probe_ids, self.user_turn_prefix_ids), max(0, lp_probe - 1))
            q_end_probe = lp_probe
            lu_probe = max(1, lp_probe - q_start_probe)

        base_pos = int(self.session_pos)
        if base_pos == 0:
            prompt_ids = clean_probe_ids
        else:
            prompt_ids = list(
                tok.encode(f"<|im_start|>user\n{user_query}<|im_end|>\n<|im_start|>assistant\n", add_special_tokens=False)
            )
        effective_lp = len(prompt_ids)
        scache_b0 = self.scache_gpu_bytes
        use_guard = bool(enable_epistemic_guard and enable_scarstore and self.router_meta is not None)
        epistemic_mode = "base_trunk"
        guarded_rollback_pos: Optional[int] = None
        guarded_clean_prefix_ids: Optional[List[int]] = None

        U = self.wgpu.BufferUsage
        t0 = time.perf_counter()

        if base_pos == 0:
            if (
                enable_scarstore
                and self.router_meta is not None
                and self.is_golden_slice_v4
                and 0 < q_end_probe < lp_probe
            ):
                prefill_xin_buf = self.device.create_buffer(
                    size=lu_probe * self.hidden_dim * 4, usage=U.COPY_DST | U.COPY_SRC
                )
                self._submit_prefill_sequence(
                    clean_probe_ids[:q_end_probe],
                    0,
                    q_start_probe,
                    prefill_xin_buf,
                    q_end=q_end_probe,
                    run_full_on_last=True,
                )
                xin_np = np.frombuffer(self.device.queue.read_buffer(prefill_xin_buf), dtype=np.float32).reshape(
                    lu_probe, self.hidden_dim
                )
                active = self.route_prompt_states(xin_np)
                self._set_active_capsules_gpu(active, horizon_scale=1.0)
                if len(active) > 0 or not use_guard:
                    epistemic_mode = "scar_grounded" if len(active) > 0 else "base_trunk"
                    tail_ids = clean_probe_ids[q_end_probe:]
                    self._submit_prefill_sequence(
                        tail_ids,
                        q_end_probe,
                        0,
                        None,
                        q_end=None,
                        run_full_on_last=False,
                    )
                    effective_lp = q_end_probe + len(tail_ids)
                else:
                    epistemic_mode = "out_of_cone_guarded"
                    enc_snap_q = self.device.create_command_encoder()
                    enc_snap_q.copy_buffer_to_buffer(
                        self.scache_kv_buf, 0, self.scache_kv_snap_buf, 0, self.scache_kv_buf.size
                    )
                    enc_snap_q.copy_buffer_to_buffer(
                        self.scache_w_scar_buf, 0, self.scache_w_scar_snap_buf, 0, self.scache_w_scar_buf.size
                    )
                    enc_snap_q.copy_buffer_to_buffer(
                        self.scache_salience_buf, 0, self.scache_sal_snap_buf, 0, self.scache_salience_buf.size
                    )
                    self.device.queue.submit([enc_snap_q.finish()])
                    guarded_rollback_pos = q_end_probe
                    guarded_clean_prefix_ids = list(clean_probe_ids[q_end_probe:])

                    gate_txt = select_out_of_cone_epistemic_gate(user_query)
                    guarded_msgs = [
                        {"role": "system", "content": sys_txt},
                        {"role": "user", "content": f"{user_query}\n\n{gate_txt}"},
                    ]
                    raw_g_enc: Any = tok.apply_chat_template(
                        guarded_msgs, tokenize=True, add_generation_prompt=True
                    )
                    guarded_full_ids: List[int] = list(
                        raw_g_enc["input_ids"] if hasattr(raw_g_enc, "keys") else raw_g_enc
                    )
                    self.device.queue.write_buffer(self.scache_kv_buf, 0, bytes(self.scache_kv_buf.size))
                    self.device.queue.write_buffer(self.scache_w_scar_buf, 0, bytes(self.scache_w_scar_buf.size))
                    self.device.queue.write_buffer(
                        self.scache_salience_buf, 0, bytes(self.scache_salience_buf.size)
                    )
                    self._submit_prefill_sequence(
                        guarded_full_ids,
                        0,
                        0,
                        None,
                        q_end=None,
                        run_full_on_last=False,
                    )
                    effective_lp = len(guarded_full_ids)
            else:
                prefill_xin_buf = (
                    self.device.create_buffer(size=lu_probe * self.hidden_dim * 4, usage=U.COPY_DST | U.COPY_SRC)
                    if (enable_scarstore and self.router_meta is not None)
                    else None
                )
                self._submit_prefill_sequence(prompt_ids, 0, q_start_probe, prefill_xin_buf, q_end=q_end_probe)
                if prefill_xin_buf is not None:
                    xin_np = np.frombuffer(self.device.queue.read_buffer(prefill_xin_buf), dtype=np.float32).reshape(
                        lu_probe, self.hidden_dim
                    )
                    active = self.route_prompt_states(xin_np)
                    self._set_active_capsules_gpu(active, horizon_scale=1.0)
                    epistemic_mode = "scar_grounded" if len(active) > 0 else "base_trunk"
                else:
                    self._set_active_capsules_gpu([])
                    epistemic_mode = "base_trunk"
        else:
            active_turn: List[Tuple[str, float, np.ndarray]] = []
            if enable_scarstore and self.router_meta is not None:
                prefill_xin_buf = self.device.create_buffer(
                    size=lu_probe * self.hidden_dim * 4, usage=U.COPY_DST | U.COPY_SRC
                )
                enc_save = self.device.create_command_encoder()
                enc_save.copy_buffer_to_buffer(
                    self.scache_kv_buf, 0, self.scache_kv_snap_buf, 0, self.scache_kv_buf.size
                )
                enc_save.copy_buffer_to_buffer(
                    self.scache_w_scar_buf, 0, self.scache_w_scar_snap_buf, 0, self.scache_w_scar_buf.size
                )
                enc_save.copy_buffer_to_buffer(
                    self.scache_salience_buf, 0, self.scache_sal_snap_buf, 0, self.scache_salience_buf.size
                )
                self.device.queue.submit([enc_save.finish()])

                self.device.queue.write_buffer(self.scache_kv_buf, 0, bytes(self.scache_kv_buf.size))
                self.device.queue.write_buffer(self.scache_w_scar_buf, 0, bytes(self.scache_w_scar_buf.size))
                self.device.queue.write_buffer(self.scache_salience_buf, 0, bytes(self.scache_salience_buf.size))

                probe_seq = (
                    clean_probe_ids[:q_end_probe]
                    if (self.is_golden_slice_v4 and 0 < q_end_probe < lp_probe)
                    else clean_probe_ids
                )
                self._submit_prefill_sequence(probe_seq, 0, q_start_probe, prefill_xin_buf, q_end=q_end_probe)

                enc_restore = self.device.create_command_encoder()
                enc_restore.copy_buffer_to_buffer(
                    self.scache_kv_snap_buf, 0, self.scache_kv_buf, 0, self.scache_kv_buf.size
                )
                enc_restore.copy_buffer_to_buffer(
                    self.scache_w_scar_snap_buf, 0, self.scache_w_scar_buf, 0, self.scache_w_scar_buf.size
                )
                enc_restore.copy_buffer_to_buffer(
                    self.scache_sal_snap_buf, 0, self.scache_salience_buf, 0, self.scache_salience_buf.size
                )
                self.device.queue.submit([enc_restore.finish()])

                xin_np = np.frombuffer(self.device.queue.read_buffer(prefill_xin_buf), dtype=np.float32).reshape(
                    lu_probe, self.hidden_dim
                )
                active_turn = self.route_prompt_states(xin_np)
                self._set_active_capsules_gpu(active_turn, horizon_scale=1.0)
            else:
                self._set_active_capsules_gpu([])

            if enable_scarstore and self.router_meta is not None and len(active_turn) == 0 and use_guard:
                epistemic_mode = "out_of_cone_guarded"
                guarded_rollback_pos = base_pos
                guarded_clean_prefix_ids = list(prompt_ids)
                gate_txt = select_out_of_cone_epistemic_gate(user_query)
                turn_ids = list(
                    tok.encode(
                        f"<|im_start|>user\n{user_query}\n\n{gate_txt}<|im_end|>\n<|im_start|>assistant\n",
                        add_special_tokens=False,
                    )
                )
            else:
                epistemic_mode = (
                    "scar_grounded"
                    if (enable_scarstore and self.router_meta is not None and len(active_turn) > 0)
                    else "base_trunk"
                )
                turn_ids = prompt_ids
            self._submit_prefill_sequence(turn_ids, base_pos, 0, None)
            effective_lp = len(turn_ids)

        # Complete upper layers -> final_norm -> scar_inject -> lm_head -> top2 for `effective_lp - 1`
        split_idx = self.mid_layer_idx if self.is_golden_slice_v4 else (self.num_layers - 2)
        enc_tail = self.device.create_command_encoder()
        cpass_tail = enc_tail.begin_compute_pass()
        if self.is_golden_slice_v4 and self.scar_mid_inject_op is not None:
            self._record_ops(cpass_tail, [self.scar_mid_inject_op])
        for l_i in range(split_idx + 1, self.num_layers):
            self._record_ops(cpass_tail, self.layer_ops[l_i])
        self._record_ops(cpass_tail, [self.final_norm_op, self.scar_inject_op])
        self._record_ops(cpass_tail, self.lm_head_ops)
        self._record_ops(cpass_tail, self.reduce_ops)
        cpass_tail.end()
        self.device.queue.submit([enc_tail.finish()])

        raw16 = self.device.queue.read_buffer(self.top2_out_buf)
        prefill_ms = (time.perf_counter() - t0) * 1000.0
        scache_b_prefill = self.scache_gpu_bytes

        top1_id, v1_u32, v2_u32, sexp_u32 = struct.unpack("<4I", raw16)
        v1 = struct.unpack("<f", struct.pack("<I", v1_u32))[0]
        v2 = struct.unpack("<f", struct.pack("<I", v2_u32))[0]
        sexp = max(struct.unpack("<f", struct.pack("<I", sexp_u32))[0], 1e-12)

        gen_ids: List[int] = []
        confs: List[float] = [1.0 / sexp]
        margins: List[float] = [(1.0 - math.exp(max(-80.0, v2 - v1))) / sexp]
        last_gen_fed = True
        last_decoded = ""
        if int(top1_id) not in self.eos_token_ids:
            gen_ids.append(int(top1_id))
            last_gen_fed = False
            last_decoded = tok.decode(gen_ids, skip_special_tokens=True)

        max_spread = 0.0
        if not self.is_golden_slice_v4 and self._current_m_active >= 2:
            tel = np.frombuffer(self.device.queue.read_buffer(self.scar_telemetry_buf), dtype=np.float32)
            max_spread = max(max_spread, float(tel[8]))

        t_dec0 = time.perf_counter()
        cur_pos = base_pos + effective_lp
        dec_step_idx = 0
        while len(gen_ids) > 0 and len(gen_ids) < max_new_tokens and gen_ids[-1] not in self.eos_token_ids:
            dec_step_idx += 1
            if self.is_golden_slice_v4 and self._current_m_active > 0:
                self._update_horizon_scale_gpu(dec_step_idx)
            nxt_id, p1, marg, _ = self.forward_token(gen_ids[-1], cur_pos, return_full_logits=False)
            cur_pos += 1
            last_gen_fed = True
            if not self.is_golden_slice_v4 and self._current_m_active >= 2:
                tel = np.frombuffer(self.device.queue.read_buffer(self.scar_telemetry_buf), dtype=np.float32)
                max_spread = max(max_spread, float(tel[8]))
            if nxt_id in self.eos_token_ids:
                break
            if _should_stop_at_sentence_boundary(
                epistemic_mode, len(gen_ids), dec_step_idx, self.seed_horizon, max_new_tokens
            ) and _ends_with_complete_sentence(last_decoded):
                nxt_piece = tok.decode([nxt_id], skip_special_tokens=True)
                if _starts_new_sentence_or_paragraph(nxt_piece):
                    break
            gen_ids.append(nxt_id)
            last_gen_fed = False
            confs.append(p1)
            margins.append(marg)
            rep_start = _find_repeated_ngram_start(gen_ids)
            if rep_start >= 0:
                del gen_ids[rep_start:]
                last_decoded = tok.decode(gen_ids, skip_special_tokens=True).rstrip()
                break
            preview_txt = tok.decode(gen_ids, skip_special_tokens=True)
            if (
                _should_stop_at_sentence_boundary(
                    epistemic_mode, len(gen_ids), dec_step_idx, self.seed_horizon, max_new_tokens
                )
                and bool(re.search(r"\n\s*$", preview_txt))
                and _ends_with_complete_sentence(preview_txt)
            ):
                last_decoded = preview_txt.rstrip()
                break
            last_decoded = preview_txt

        turn_active_cids = list(self._current_active_cids)
        turn_active_gates = dict(self._current_active_gates)
        self._set_active_capsules_gpu([])
        turn_suffix_ids = list(tok.encode("<|im_end|>\n", add_special_tokens=False))
        if guarded_rollback_pos is not None and guarded_clean_prefix_ids is not None:
            enc_clean_rest = self.device.create_command_encoder()
            enc_clean_rest.copy_buffer_to_buffer(
                self.scache_kv_snap_buf, 0, self.scache_kv_buf, 0, self.scache_kv_buf.size
            )
            enc_clean_rest.copy_buffer_to_buffer(
                self.scache_w_scar_snap_buf, 0, self.scache_w_scar_buf, 0, self.scache_w_scar_buf.size
            )
            enc_clean_rest.copy_buffer_to_buffer(
                self.scache_sal_snap_buf, 0, self.scache_salience_buf, 0, self.scache_salience_buf.size
            )
            self.device.queue.submit([enc_clean_rest.finish()])
            clean_gen_ids = [t for t in gen_ids if t not in self.eos_token_ids]
            clean_flush_ids = list(guarded_clean_prefix_ids) + clean_gen_ids + turn_suffix_ids
            self.session_pos = self._flush_closing_tokens_to_scache(clean_flush_ids, guarded_rollback_pos)
        else:
            closing_ids: List[int] = []
            if gen_ids and not last_gen_fed:
                closing_ids.append(gen_ids[-1])
            closing_ids.extend(turn_suffix_ids)
            self.session_pos = self._flush_closing_tokens_to_scache(closing_ids, cur_pos)
        self.turn_count += 1

        decode_ms = (time.perf_counter() - t_dec0) * 1000.0
        scache_b_end = self.scache_gpu_bytes
        clean_ids = [t for t in gen_ids if t not in self.eos_token_ids]
        answer = tok.decode(clean_ids, skip_special_tokens=True).strip()
        dec_steps = max(1, len(gen_ids) - 1)
        tok_s = (dec_steps / (decode_ms / 1000.0)) if decode_ms > 0.0 and len(gen_ids) > 1 else 0.0

        return WebGPUGenerationResult(
            prompt=user_query,
            answer=answer,
            generated_token_ids=clean_ids,
            prefill_tokens=effective_lp,
            generated_tokens=len(clean_ids),
            prefill_ms=round(prefill_ms, 3),
            decode_ms=round(decode_ms, 3),
            decode_tok_per_s=round(tok_s, 2),
            adapter_name=self.adapter_name,
            backend_type=self.backend_type,
            scache_bytes_initial=scache_b0,
            scache_bytes_after_prefill=scache_b_prefill,
            scache_bytes_after_decode=scache_b_end,
            scache_delta_bytes=scache_b_end - scache_b0,
            vram_weights_mib=round(self.total_weight_gpu_bytes / (1024.0 * 1024.0), 3),
            active_capsules=turn_active_cids,
            active_gates=turn_active_gates,
            http206_bytes_fetched=int(self.http206_bytes_fetched),
            mean_confidence_p1=round(sum(confs) / len(confs), 4),
            mean_margin_p1_p2=round(sum(margins) / len(margins), 4),
            max_inter_head_spread=round(max_spread, 4),
            epistemic_mode=epistemic_mode,
        )


_RANGE_HEADER_RE = re.compile(r"^bytes=(\d+)-(\d*)$")


class WebGPUStaticRangeServer:
    """Zero-Python-Inference Static + RFC 7233 `HTTP/1.1 206 Partial Content` Server for Browser WebGPU.

    Overlays `scar_cache/webgpu/app/` (live development / packaged UI) with `bundle_dir` (`.bin` shards,
    `webgpu_manifest.json`, `tokenizer.json`, `scarstore_router.*`, `capsules.scarstore`).
    """

    def __init__(
        self,
        bundle_dir: Union[str, Path],
        host: str = "127.0.0.1",
        port: int = 8780,
        app_dir: Optional[Union[str, Path]] = None,
    ) -> None:
        self.bundle_dir = Path(bundle_dir).resolve()
        self.app_dir = Path(app_dir).resolve() if app_dir is not None else WEBGPU_APP_DIR.resolve()
        self.host = host
        self.port = int(port)
        self._httpd: Optional[ThreadingHTTPServer] = None
        self._thread: Optional[threading.Thread] = None
        self.range_requests_served = 0

    def _resolve_file(self, url_path: str) -> Optional[Path]:
        clean = unquote(url_path.split("?", 1)[0].split("#", 1)[0]).lstrip("/")
        if not clean:
            clean = "index.html"
        # Prefer `app_dir` for UI assets (`index.html`, `.js`, `.css`) so UI edits take effect immediately,
        # then fall back to `bundle_dir` for model shards, manifests, WGSL, and `.scarstore`.
        for root in (self.app_dir, self.bundle_dir):
            if not root.exists():
                continue
            cand = (root / clean).resolve()
            if (cand == root or root in cand.parents) and cand.is_file():
                return cand
        return None

    @staticmethod
    def _guess_mime(path: Path) -> str:
        suf = path.suffix.lower()
        custom = {
            ".html": "text/html; charset=utf-8",
            ".js": "application/javascript; charset=utf-8",
            ".mjs": "application/javascript; charset=utf-8",
            ".css": "text/css; charset=utf-8",
            ".json": "application/json; charset=utf-8",
            ".wgsl": "text/plain; charset=utf-8",
            ".bin": "application/octet-stream",
            ".scarstore": "application/octet-stream",
        }
        if suf in custom:
            return custom[suf]
        guessed, _ = mimetypes.guess_type(str(path))
        return guessed or "application/octet-stream"

    def start(self, background: bool = True) -> str:
        outer = self

        class _Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def log_message(self, format: str, *args: Any) -> None:
                return

            def _send_cors(self) -> None:
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS")
                self.send_header("Access-Control-Allow-Headers", "Range, Content-Type")
                self.send_header("Access-Control-Expose-Headers", "Content-Range, Content-Length, Accept-Ranges")
                self.send_header("Accept-Ranges", "bytes")
                self.send_header("Cache-Control", "no-cache")

            def do_OPTIONS(self) -> None:
                self.send_response(HTTPStatus.NO_CONTENT)
                self._send_cors()
                self.send_header("Content-Length", "0")
                self.end_headers()

            def do_HEAD(self) -> None:
                self._serve(send_body=False)

            def do_GET(self) -> None:
                self._serve(send_body=True)

            def _serve(self, send_body: bool) -> None:
                fpath = outer._resolve_file(self.path)
                if fpath is None:
                    body = b"Not Found"
                    self.send_response(HTTPStatus.NOT_FOUND)
                    self._send_cors()
                    self.send_header("Content-Type", "text/plain; charset=utf-8")
                    self.send_header("Content-Length", str(len(body)))
                    self.end_headers()
                    if send_body:
                        self.wfile.write(body)
                    return

                fsize = int(fpath.stat().st_size)
                ctype = outer._guess_mime(fpath)
                rng_hdr = self.headers.get("Range")
                if rng_hdr:
                    m = _RANGE_HEADER_RE.match(rng_hdr.strip())
                    if not m:
                        self.send_response(HTTPStatus.REQUESTED_RANGE_NOT_SATISFIABLE)
                        self._send_cors()
                        self.send_header("Content-Range", f"bytes */{fsize}")
                        self.send_header("Content-Length", "0")
                        self.end_headers()
                        return
                    start = int(m.group(1))
                    end = int(m.group(2)) if m.group(2) else (fsize - 1)
                    end = min(end, fsize - 1)
                    if start < 0 or start >= fsize or end < start:
                        self.send_response(HTTPStatus.REQUESTED_RANGE_NOT_SATISFIABLE)
                        self._send_cors()
                        self.send_header("Content-Range", f"bytes */{fsize}")
                        self.send_header("Content-Length", "0")
                        self.end_headers()
                        return
                    length = end - start + 1
                    outer.range_requests_served += 1
                    self.send_response(HTTPStatus.PARTIAL_CONTENT)
                    self._send_cors()
                    self.send_header("Content-Type", ctype)
                    self.send_header("Content-Range", f"bytes {start}-{end}/{fsize}")
                    self.send_header("Content-Length", str(length))
                    self.end_headers()
                    if send_body:
                        with open(fpath, "rb") as rf:
                            rf.seek(start)
                            self.wfile.write(rf.read(length))
                    return

                self.send_response(HTTPStatus.OK)
                self._send_cors()
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(fsize))
                self.end_headers()
                if send_body:
                    with open(fpath, "rb") as rf:
                        shutil.copyfileobj(rf, self.wfile, length=1024 * 1024)

        self._httpd = ThreadingHTTPServer((self.host, self.port), _Handler)
        self.port = int(self._httpd.server_address[1])
        url = f"http://{self.host}:{self.port}"
        if background:
            self._thread = threading.Thread(target=self._httpd.serve_forever, daemon=True)
            self._thread.start()
        return url

    def serve_forever(self) -> None:
        if self._httpd is None:
            self.start(background=False)
        assert self._httpd is not None
        self._httpd.serve_forever()

    def stop(self) -> None:
        if self._httpd is not None:
            self._httpd.shutdown()
            self._httpd.server_close()
            self._httpd = None
        if self._thread is not None:
            self._thread.join(timeout=2.0)
            self._thread = None


def verify_webgpu_mos_parity(
    bundle_dir: Union[str, Path],
    prompt: str = "Explain concisely what Landauer's principle states for the minimum energy dissipated when erasing one bit at temperature T.",
    max_new_tokens: int = 32,
) -> Dict[str, Any]:
    """Runs `NativeWebGPUMoSEngine` on physical GPU (`wgpu-py`) and audits `SCache O(1)` + `ScarStore` parity."""
    engine = NativeWebGPUMoSEngine(bundle_dir=bundle_dir)
    res_base = engine.generate(prompt, max_new_tokens=max_new_tokens, enable_scarstore=False)
    res_scar = engine.generate(prompt, max_new_tokens=max_new_tokens, enable_scarstore=True)
    return {
        "adapter": engine.adapter_name,
        "backend": engine.backend_type,
        "vram_weights_mib": res_scar.vram_weights_mib,
        "scache_gpu_bytes": engine.scache_gpu_bytes,
        "scache_delta_bytes": res_scar.scache_delta_bytes,
        "without_scarstore": asdict(res_base),
        "with_scarstore": asdict(res_scar),
    }


def main_cli(argv: Optional[Sequence[str]] = None) -> None:
    """Console entry point for `mos-webgpu` (`export`, `verify`, `serve`)."""
    parser = argparse.ArgumentParser(
        prog="mos-webgpu",
        description="Native WebGPU / WGSL Engine for Mixture of Scars (MoS) + SCache O(1) + HTTP 206 ScarStore",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_exp = sub.add_parser("export", help="Export an MoS Student + ScarStore into <80 MiB WebGPU binary shards")
    p_exp.add_argument("--model", default="Qwen/Qwen2.5-0.5B-Instruct", help="HF model ID or cached MoS directory")
    p_exp.add_argument("--out", default="./webgpu_dist/qwen0p5b", help="Target directory for WebGPU bundle")
    p_exp.add_argument("--store", default=None, help="Optional .scarstore path (auto-detected by hidden_dim if omitted)")
    p_exp.add_argument("--rank", type=int, default=128, help="MoS ASVD rank (default: 128)")
    p_exp.add_argument("--shell-only", action="store_true", help="Stream 61.25/140 KB slices from remote GitHub CDN")
    p_exp.add_argument("--offline", action="store_true", help="Use local HF cache only")

    p_ver = sub.add_parser("verify", help="Verify exported WGSL shaders on physical GPU hardware via wgpu-py")
    p_ver.add_argument("--dir", default="./webgpu_dist/qwen0p5b", help="Exported WebGPU bundle directory")
    p_ver.add_argument(
        "--prompt",
        default="Explain concisely what Landauer's principle states for the minimum energy dissipated when erasing one bit at temperature T.",
        help="Verification prompt",
    )
    p_ver.add_argument("--max-new-tokens", type=int, default=32, help="Tokens to decode on WebGPU")

    p_srv = sub.add_parser("serve", help="Serve the zero-Python static Browser WebGPU Studio with HTTP 206 Range support")
    p_srv.add_argument("--dir", default="./webgpu_dist/qwen0p5b", help="Exported WebGPU bundle directory")
    p_srv.add_argument("--host", default="127.0.0.1", help="Bind host (default: 127.0.0.1)")
    p_srv.add_argument("--port", type=int, default=8780, help="Bind port (default: 8780)")

    args = parser.parse_args(argv)
    if args.command == "export":
        rep = export_mos_model_to_webgpu(
            model_id_or_path=args.model,
            output_dir=args.out,
            scarstore_path=args.store,
            mos_rank=args.rank,
            copy_scarstore_payload=not args.shell_only,
            local_files_only=args.offline,
        )
        print(json.dumps(asdict(rep), indent=2, ensure_ascii=False))
    elif args.command == "verify":
        audit = verify_webgpu_mos_parity(
            bundle_dir=args.dir,
            prompt=args.prompt,
            max_new_tokens=args.max_new_tokens,
        )
        print(json.dumps(audit, indent=2, ensure_ascii=False))
    elif args.command == "serve":
        srv = WebGPUStaticRangeServer(bundle_dir=args.dir, host=args.host, port=args.port)
        url = srv.start(background=False)
        print(f"[mos-webgpu] Serving 100% In-Browser WebGPU + HTTP 206 ScarStore Studio at {url}", flush=True)
        try:
            srv.serve_forever()
        except KeyboardInterrupt:
            srv.stop()


if __name__ == "__main__":
    main_cli()
