# Guia Prático Oficial — Executando `Qwen2.5-72B-Instruct` (`72.71B`) Localmente com `MoS v2 + SCache O(1)`

Este guia mostra passo a passo como baixar, auditar e executar localmente o modelo **`Qwen/Qwen2.5-72B-Instruct` (`72.71 bilhões` de parâmetros, `80` camadas, `145.4 GB` em BF16 denso)** em notebooks e desktops convencionais (**Apple Silicon M1/M2/M3/M4 de `8 GB` / `16 GB+`**, **GPUs NVIDIA de `8 GB` a `24 GB+`** ou **CPU**) usando a arquitetura genuína:

1. **Mixture of Scars (`MoS v2` Canônico):** Decomposição de cada projeção linear (`240` matrizes SwiGLU MLP `[29568, 8192]` + `320` projeções de Atenção GQA) em **Base Simétrica `Block-64 INT4`** acoplada a **Especialistas Residuais de Baixo Posto ponderados por ativação (`ASVD`, `rank=48` MLP / `rank=32` Atenção)**, preservando canais outliers emergentes (`>6.7B`) em **20 grupos de 4 camadas (`1.79 GiB` por shard)**.
2. **Scar-Cache (`SCacheDynamicCache` $\mathcal{O}(1)$):** Substituição do KV Cache linear $\mathcal{O}(T)$ por uma janela física fixa combinada a **memória associativa ortogonal online de Widrow-Hoff** (`ΔBytes = +0.00 B` para qualquer comprimento de contexto $L > W$).

---

## 1. Requisitos de Hardware e Dimensionamento Real

| Plataforma Local | Modo Recomendado | Throughput (`tok/s` Decode) | Pico Ativo (`MoS` GPU / MPS) | Memória de Contexto (`SCache O(1)`, `W=256, S=24`) |
|---|---|---|---|---|
| **Apple Silicon (`8 GB` / `16 GB` M1–M4)** | `--device mps` (Streaming) | `0.023 tok/s` (`4.23 tok/s` prefill; limitado por NVMe) | **`1.92 GiB` MPS** (`120.6 MiB` pós-unload · `0.52 GiB` RSS) | **`128.51 MiB` constantes** (`+0 B` em `16k–128k` tok) |
| **Apple M2 Pro (`32 GB` máx SKU, `200 GB/s`)** | `--device mps` (Cache Híbrido RAM+NVMe) | `~0.40–0.55 tok/s` (`2.57 tok/s` teto de barramento) | **`1.92 GiB` MPS ativo** (`~24 GiB` page cache OS) | **`128.51 MiB` constantes** |
| **Apple M4 Pro (`48 GB`) / M2–M4 Max (`64 GB+`)** | `--device mps --resident` (Fused Metal `INT4`) | **`~3.46 – 4.87 tok/s`** (`50.4x` kernel speedup) | **`38.56 GiB` Unified MPS** (`0 MB/tok` SSD) | **`128.51 MiB` constantes** (poupa `>10.5 GiB` em `32k`) |
| **GPU Consumidora NVIDIA (`8 GB–24 GB`)** | `--device cuda` (Fused Triton `W4A16+ASVD` / `int4pack`) | **`4.03 – 7.27+ tok/s`** | **`1.79 GiB`/shard** a `38.6 GiB` VRAM | **`128.51 MiB` VRAM constantes** |

> **Telemetria Real Verificada em Apple Silicon M2 (`16.0 GB` Unified RAM, `MPS` — [`results/scale_72b_audit/apple_m2_72b_speed_memory_audit.json`](../results/scale_72b_audit/apple_m2_72b_speed_memory_audit.json) & [`apple_m2_live_72b_generation.json`](../results/scale_72b_audit/apple_m2_live_72b_generation.json)) e Kernels Fundidos Multi-Hardware:**
> - **Apple Silicon (`MPS`):** Com os kernels nativos Apple Metal `torch._weight_int4pack_mm` acoplados às cicatrizes `ASVD` (`rank=48`), a paridade numérica em 4 camadas completas do `72B` atingiu **`cos = 1.000000`** (`rel_diff = 0.00062`) reduzindo a latência de computação por grupo de `1.495,3 ms` para **`29,7 ms` (`50,38x` mais rápido)**. Em máquinas de `8 GB` / `16 GB` (`--streaming`), o motor mantém apenas **`1.92 GiB` de pico ativo no `MPS`** (`0.52 GiB` de RSS Python) com prefill de **`4.23 tok/s`**, enquanto em Macs com `>= 48 GB` (`M4 Pro 48 GB` / `M2 Max 64 GB+`), `--resident` entrega **`~3.46–4.87 tok/s`** sem I/O de disco.
> - **NVIDIA `CUDA` (`sm_75+` Turing `T4` até `Hopper/Blackwell`):** O módulo [`scar_cache/triton_mos_gemm.py`](../scar_cache/triton_mos_gemm.py) executa desempacotamento `Block-64 INT4` direto nos registradores (`_fused_int4_mos_gemv_decode_kernel` para `M <= 8` e `_fused_int4_mos_gemm_prefill_kernel` em Tensor Cores `tl.dot` para `M > 8`) fundido ao epílogo `ASVD` (`h_scar @ B_scar.T`) e à escala dinâmica contra outliers SwiGLU de `195.720x` — funcionando com **zero custo de swizzle** tanto em `--streaming` quanto em `--resident` (com suporte adicional a `torch._weight_int4pack_mm` validado automaticamente em GPUs `sm_80+` via `MOS_CUDA_BACKEND=int4pack`).

---

## 2. Instalação Rápida (`< 1 minuto`)

```bash
git clone https://github.com/byte-od/mixture-of-scars.git
cd mixture-of-scars
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -e . "transformers>=5.0.0" "safetensors>=0.4.3" "accelerate>=0.34.0" "huggingface_hub>=0.26.0"
```

---

## 3. Download Público Oficial do Checkpoint `Qwen2.5-72B-Instruct MoS v2` (`38.12 GiB`)

Todos os `22` shards `.safetensors` (`mos_embed_tokens.safetensors`, `mos_group_00.safetensors` .. `mos_group_19.safetensors`, `mos_lm_head.safetensors`) possuem **`< 1.80 GiB` cada** e assinatura criptográfica **SHA-256** verificada automaticamente no manifesto [`mos_manifest.json`](../models/qwen25_72b_mos_v2/mos_manifest.json).

### Opção A — Download Direto HTTPS (Zero Login / Com Retomada Automática `Range`)
```bash
python -m scar_cache.cli_72b \
  --download \
  --model-dir ./models/qwen25_72b_mos_v2
```
*(Se a conexão oscilar, basta rodar o mesmo comando novamente: shards já verificados por SHA-256 são pulados instantaneamente e shards parciais retomam do byte exato via `HTTP 206 Range`).*

### Opção B — Download Direto via Navegador / `curl` / `aria2c` Paralelo (Zero Login)
Todos os `29` arquivos (`mos_manifest.json`, `6` arquivos de tokenizador/configuração e os `22` shards `.safetensors`) estão disponíveis publicamente em:
- **Página Oficial da Release:** https://github.com/byte-od/mixture-of-scars/releases/tag/v1.2.0-qwen72b-mos
- **Padrão de URL Direta CDN (`HTTP 206 Range`):** `https://github.com/byte-od/mixture-of-scars/releases/download/v1.2.0-qwen72b-mos/<nome_do_arquivo>`

Após baixar manualmente ou via gerenciador paralelo (`aria2c -x 16`) para `./models/qwen25_72b_mos_v2`, rode `--download` para validar instantaneamente os `22` checksums **SHA-256** antes de executar!

---

## 4. Executando Localmente (`CLI` Interativo e Prompt Direto)

### 4.1 Pergunta Única (`--prompt`)
```bash
python -m scar_cache.cli_72b \
  --model-dir ./models/qwen25_72b_mos_v2 \
  --prompt "Implemente em Python o algoritmo de Dijkstra com fila de prioridade e explique a complexidade:" \
  --max-new-tokens 128 \
  --temperature 0.0
```

### 4.2 Chat Multi-Turno no Terminal com Telemetria `SCache O(1)` ao Vivo (`--chat`)
```bash
python -m scar_cache.cli_72b \
  --model-dir ./models/qwen25_72b_mos_v2 \
  --chat \
  --window-size 256 \
  --num-slots 24
```
Comandos internos durante o chat:
- Digite sua mensagem normalmente para continuar a conversa acumulando contexto na memória associativa `SCache` com **crescimento físico de `0.00 Bytes`** após preencher a janela `W`.
- Digite `reset` para limpar as cicatrizes associativas do `SCache`.
- Digite `exit` ou `quit` para encerrar.

### 4.3 Ajustando a Fronteira 3D de Pareto (`Memória x Qualidade x Velocidade`)
Você pode controlar diretamente o ponto de operação do `SCache O(1)` nas `80` camadas (`8` KV heads, `head_dim=128`) via flags:
- **Ultra-Compacto (`64.73 MiB` em `S=12` / `68.51 MiB` em `S=24`):** `--window-size 64 --num-slots 24`
- **Equilibrado Padrão (`128.51 MiB` exatos em 80 camadas):** `--window-size 256 --num-slots 24`
- **Alta Retenção de Contexto Longo (`211.03 MiB` exatos em 80 camadas):** `--window-size 512 --num-slots 32`

---

## 5. Uso Programático em Python (`CanonicalMoSEngine` + `SCacheDynamicCache`)

```python
from scar_cache.cli_72b import CanonicalMoSEngine

# Inicializa o motor 72.7B em modo streaming (< 1.95 GiB por grupo ativo em MPS/CUDA)
engine = CanonicalMoSEngine(
    model_dir="./models/qwen25_72b_mos_v2",
    device="auto",       # Seleciona automaticamente cuda:0 -> mps -> cpu
    streaming=True,      # Use False em máquinas com >= 48 GB de RAM/VRAM livre
)

# Cria o cache associativo estritamente constante O(1) (Widrow-Hoff Fast Weights)
scache = engine.make_scache(window_size=256, num_slots=24, num_sinks=4)

resposta, scache = engine.generate_stream(
    prompt="Explique por que canais outliers emergentes em SwiGLU exigem cicatrizes SVD de baixo posto:",
    scache=scache,
    max_new_tokens=128,
    temperature=0.0,
)

print(f"Bytes físicos constantes do SCache: {scache.total_memory_bytes:,} B")
```

---

## 6. Como Converter Qualquer Modelo `Qwen2` / `Qwen2.5` (`0.5B` → `72B`) Você Mesmo

Toda a pipeline de conversão canônica é 100% aberta e reprodutível via [`scripts/export_canonical_72b_mos.py`](../scripts/export_canonical_72b_mos.py):

### Teste Local Instantâneo em `0.5B` ou `7B`:
```bash
python scripts/export_canonical_72b_mos.py \
  --model-id Qwen/Qwen2.5-7B-Instruct \
  --out-dir ./models/qwen25_7b_mos_v2 \
  --layers-per-group 4 \
  --mlp-rank 48 \
  --attn-rank 32

python -m scar_cache.cli_72b \
  --model-dir ./models/qwen25_7b_mos_v2 \
  --chat
```

### Conversão Completa do `Qwen/Qwen2.5-72B-Instruct` (Único Comando ou Multi-Partes):
```bash
python scripts/export_canonical_72b_mos.py \
  --model-id Qwen/Qwen2.5-72B-Instruct \
  --out-dir ./models/qwen25_72b_mos_v2 \
  --layers-per-group 4 \
  --mlp-rank 48 \
  --attn-rank 32
```

---

## 7. Auditoria Reprodutível de `16.6k` & `32.9k` Passkey / Needle-in-a-Haystack e Seleção de Kernels

### 7.1 Benchmark `16.6k` & `32.9k` Passkey (`SCache O(1)` vs. Normal KV vs. `StreamingLLM`)
```bash
# Reproduz a auditoria oficial em documentação real da biblioteca padrão do Python (salva JSON com prova ΔBytes = 0 B):
python scripts/benchmark_16k_passkey_llm.py \
  --models Qwen/Qwen2.5-0.5B-Instruct Qwen/Qwen2.5-3B-Instruct \
  --lengths 16500 32800
```

### 7.2 Benchmark de Velocidade & Memória `72.71B` Fused Metal (`Apple Silicon`) e `CUDA`
```bash
# Apple Silicon (mede paridade cos=1.000000 do _weight_int4pack_mm e roda 80L --resident automaticamente em Macs >=48 GB):
python scripts/benchmark_72b_apple_silicon.py

# NVIDIA CUDA — seleção explícita opcional do backend INT4 (padrão: auto = triton -> int4pack -> dequant):
MOS_CUDA_BACKEND=triton python -m scar_cache.cli_72b --model-dir ./models/qwen25_72b_mos_v2 --chat
```

- **Preprint Acadêmico Oficial (`v1.3.0`, CERN / Zenodo DOI):** [`10.5281/zenodo.24143839`](https://doi.org/10.5281/zenodo.24143839) ([`Mixture_of_Scars_and_SCache_Preprint_v1.3.pdf`](../zenodo_deposit_v1_3/Mixture_of_Scars_and_SCache_Preprint_v1.3.pdf))

---

## 8. Citação Oficial (Preprint `v1.3.0` + Checkpoint `72.71B MoS v2` & Guia Prático)

Ao utilizar a arquitetura `MoS + SCache O(1)`, o checkpoint público `Qwen2.5-72B-Instruct MoS v2` (`38.12 GiB`) ou este Guia Prático em artigos, benchmarks ou aplicações, cite:

```bibtex
@techreport{reisfilho2026mos_scache,
  author      = {Reis Filho, Julio Cesar},
  title       = {Mixture of Scars (MoS) and SCache O(1): Breaking the Dual Memory Wall Across 0.5B -> 7.62B -> 72.71B Transformers via Fused Activation-Aware Scar Experts and 32k Widrow-Hoff Associative Memory},
  institution = {Byte-OD Research \& System One Architecture Lab},
  year        = {2026},
  month       = nov,
  version     = {1.3.0},
  doi         = {10.5281/zenodo.24143839},
  url         = {https://doi.org/10.5281/zenodo.24143839}
}

@misc{reisfilho2026qwen72b_mos_v2,
  author       = {Reis Filho, Julio Cesar},
  title        = {Qwen2.5-72B-Instruct MoS v2 (72.71B, 38.12 GiB Canonical INT4+ASVD Checkpoint) and Official Practical Local Deployment Guide},
  howpublished = {Public SHA-256 Verified Checkpoint Release (\texttt{mos-run --download}) and Practical Guide (\texttt{docs/GUIA\_PRATICO\_MOS\_SCACHE\_72B.md})},
  year         = {2026},
  url          = {https://github.com/byte-od/mixture-of-scars/releases/tag/v1.2.0-qwen72b-mos},
  note         = {Practical Guide: https://github.com/byte-od/mixture-of-scars/blob/main/docs/GUIA_PRATICO_MOS_SCACHE_72B.md}
}
```
